<?php
include "connect.php";
if(isset($_POST["submit"]))
{
	$id=$_POST["cid"];
	$cname=$_POST["cname"];
	$cno=$_POST["cno"];
	$colour=$_POST["select"];
	$rate=$_POST["rate"];
	
	
	if(!empty($_FILES['file1']['name']))
	{
		$target_dir = "wedding/";
		$file = $target_dir . basename($_FILES["file1"]["name"]);
		
		$fileData = pathinfo(basename($_FILES["file1"]["name"]));
		
				
		$fileName = uniqid() . '.' . $fileData['extension'];
		$target_path = "wedding/" . $fileName;
			
		while(file_exists($target_path))
		{
			$fileName = uniqid() . '.' . $fileData['extension'];
			$target_path = "wedding/" . $fileName;
		}
		move_uploaded_file($_FILES["file1"]["tmp_name"], $target_path);
		
		$image="wedding/" . $fileName;
	}
	
	
	//echo $image;
	$sql="update wedding set car='$cname',No='$cno',color='$colour',rate='$rate',status='0' where id='$id'";
	$result=mysql_query($sql,$link);
	if($result)
	{
		header("location:wcarview.php?cid=1".$id);
		return;
	}
	else
	{
		echo mysql_error();
	}
	
}
?>

	