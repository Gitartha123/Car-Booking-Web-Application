<?php
include "connect.php";
if(isset($_POST["submit"]))
{
	$id=$_POST["cid"];
	$dname=$_POST["dname"];
	$contact=$_POST["contact"];
    $image=$_POST["photo"];
	
	if(!empty($_FILES['file1']['name']))
	{
		$target_dir = "drivers/";
		$file = $target_dir . basename($_FILES["file1"]["name"]);
		
		$fileData = pathinfo(basename($_FILES["file1"]["name"]));
		
				
		$fileName = uniqid() . '.' . $fileData['extension'];
		$target_path = "drivers/" . $fileName;
			
		while(file_exists($target_path))
		{
			$fileName = uniqid() . '.' . $fileData['extension'];
			$target_path = "drivers/" . $fileName;
		}
		move_uploaded_file($_FILES["file1"]["tmp_name"], $target_path);
		
		$image="drivers/" . $fileName;
	}
	
	
	//echo $image;
	$sql="update drivers set name='$dname',contact='$contact',photo='$image' where id='$id'";
	$result=mysql_query($sql,$link);
	if($result)
	{
		header("location:viewdriver.php?cid=1".$id);
		return;
	}
	else
	{
		echo mysql_error();
	}
}
?>

	