<?php
	include "connect.php";
	$rn=$_GET["rn"];
	mysql_query("delete from room where id='$rn'");
	header("location:viewdriver.php");
?>