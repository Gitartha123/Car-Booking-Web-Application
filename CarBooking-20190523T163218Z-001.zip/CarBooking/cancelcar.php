<?php
	include "connect.php";
    $id=$_GET["bid"];
	mysql_query("update booking set status='Cancelled' where bid='$id'");
	header("location:mybooking.php");
?>