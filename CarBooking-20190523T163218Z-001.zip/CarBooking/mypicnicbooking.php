<?php
	session_start();
?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Rent a Car</title>
<link href="a1style.css" rel="stylesheet">
<style>
	.nounder
	{
		text-decoration:none;	
	}
	.nounder:hover
	{
		color:#0C6;	
	}
</style>
<script>
function myFunction() {
    var x = document.getElementById("vmenu");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}

</script>
</head>

<body>
<div class="a1-container a1-red a1-small a1-padding-8">
	<div class="a1-row">
    	<div class="a1-half">
        	<div class="a1-bar">
        		<span class="a1-bar-item">Phone : +91-9954425896 | Email : customercare@easyway.com</span>
            </div>
        </div>
        <div class="a1-half">
        	<div class="a1-bar">
            	 <a href="logout.php" class="a1-bar-item a1-hide-small nounder">Logout</a>
            	           	
<a href="userhome.php" class="a1-bar-item nounder"> Home</a>
<div class="a1-dropdown-hover">
    <button class="a1-button a1-hover-red">View booking</button>
    <div class="a1-dropdown-content a1-bar-block a1-card-4 a1-red" style="width:100px;">
      <a href="mybooking.php" class="a1-bar-item a1-button a1-hover-yellow">Car booking</a>
      <a href="mywcarbooking.php" class="a1-bar-item a1-button a1-hover-yellow">Wedding car booking</a>
      <a href="mypicnicbooking.php" class="a1-bar-item a1-button a1-hover-yellow">Picnic Package booking</a>
     
    </div>
  
</div>

      <a href="carrental.php" class="a1-bar-item nounder">Car Rental</a>
      <a href="weddingcars.php" class="a1-bar-item nounder">Wedding Cars</a>
      <a href="busforpicnic.php" class="a1-bar-item nounder">Bus for Picnic</a>
    </div>
            </div>
        </div>
    </div>
	
</div>
<img src="images/car-rental.png" style="width:100%;"/>
<div class="a1-container a1-small" style="margin-top:20px; margin-bottom:20px;">
	<div class="a1-card" style="width:1000px; margin:0 auto;">
	  <div class="a1-container a1-blue-gray">
      	<h6>View Car Booking</h6>
      </div>
      <div class="a1-container a1-small a1-padding-12">
        <table class="a1-table-all" width="100%" border="0" cellspacing="2" cellpadding="0">
      		    <tr class="a1-blue-gray">
                <td>Booking id</td>
      		      <td>Book Date</td>
      		      <td>Picnic Date</td>
      		      <td>Rate type</td>
                   <td>Picnic place</td>
      		      <td>Pick up time</td>
      		      <td>Deposit</td>
      		      <td>Status</td>
      		      <td>&nbsp;</td>
   		        </tr>
                <?php
					include "connect.php";
					 $cid=$_SESSION["username"];
					$result=mysql_query("Select * from picnicbooking where cid='$cid'");
			
					while($row=mysql_fetch_array($result))
					{
						echo '<tr>';
						echo '<td>'.$row["bid"].'</td>';
						echo '<td>'.$row["bdate"].'</td>';
						echo '<td>'.$row["pdate"].'</td>';
						echo '<td>'.$row["ratetype"].'</td>';
						echo '<td>'.$row["pplace"].'</td>';
						echo '<td>'.$row["ptime"].'</td>';
						echo '<td>'.$row["deposit"].'</td>';
						echo '<td>'.$row["status"].'</td>';
						if($row["status"]=="Cancelled")
						{
							echo '<td>No Action</td>';	
						}
						else
						{
							echo '<td><a class="a1-btn a1-green a1-round" href="cancelpicnic.php?bid='.$row["bid"].'">Cancel Booking</a></td>';
						}
				        
					}
				?>
        </table>
        
        <table class="a1-table-all" width="100%" border="0" cellspacing="2" cellpadding="0">
        </table>
      </div>
      
  </div>
</div>
<div class="a1-container a1-blue-gray a1-padding-16">
	<div style="float:left;">Copyright @ easyway cars</div>
    <div style="float:right;">
    	Designed By 
    </div>
</div>
</body>
</html>
