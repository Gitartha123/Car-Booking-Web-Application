<?php
include "connect.php";
if(isset($_POST["submit"]))
{
	$name=$_POST["dname"];
	$contact=$_POST["contact"];

	$target_dir = "drivers/";
	$file = $target_dir . basename($_FILES["file1"]["name"]);
	
	$fileData = pathinfo(basename($_FILES["file1"]["name"]));
	
			
	$fileName = uniqid() . '.' . $fileData['extension'];
	$target_path = "drivers/" . $fileName;
		
	while(file_exists($target_path))
	{
		$fileName = uniqid() . '.' . $fileData['extension'];
		$target_path = "drivers/" . $fileName;
	}
	move_uploaded_file($_FILES["file1"]["tmp_name"], $target_path);
	
	$image="drivers/" . $fileName;
	//echo $image;
    
	$sql="insert into drivers values(null,'$name','$contact','$image')";
	$result=mysql_query($sql,$link);
	if($result)
	{
		header("location:driverentry.php?ok=1");
	}
	else
	{
		echo mysql_error();
	}
}

?>

	