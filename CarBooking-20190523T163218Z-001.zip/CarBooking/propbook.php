<?php
	session_start();
	include "connect.php";
	if(isset($_POST["submit"]))
	{
		$td=mysql_real_escape_string($_POST["pdate"]);
		$pdate=date("Y-m-d",strtotime($td));
		$rate=$_POST["rate"];
		$contact=$_POST["contact"];
		$deposit=$_POST["deposit"];
		$pplace=$_POST["pplace"];
		$ptime=$_POST["ptime"];
		$bdate=date("Y-m-d");
		$place=$_POST["place"];
		$bid=substr($ptime,0,3).substr($bdate,5,2).$contact;
		$cid=$_SESSION["username"];
		$sql="insert into picnicbooking values('$bid','$bdate','$pdate','$cid','$rate','$contact','$place','$pplace','$ptime','$deposit',0,'Pending')";
		$result=mysql_query($sql);
		if($result)
		{
			header("location:userhome.php?bid=".$bid);
		}
		else
		{
			echo mysql_error();	
		}
	}
?>