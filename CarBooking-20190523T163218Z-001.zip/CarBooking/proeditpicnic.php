<?php
include "connect.php";
if(isset($_POST["submit"]))
{
	$id=$_POST["cid"];
	$place=$_POST["place"];
	$rate35=$_POST["rate35"];
	$rate42=$_POST["rate42"];
	$trate=$_POST["trate"];
	$deposit=$_POST["deposit"];
	
	
	$sql="update picnic set place='$place',rate35='$rate35',rate42='$rate42',ratetraveller='$trate',deposit='$deposit' where id='$id'";
	$result=mysql_query($sql,$link);
	if($result)
	{
		header("location:viewpicnic.php?cid=1".$id);
		return;
	}
	else
	{
		echo mysql_error();
	}
	
}
?>

	