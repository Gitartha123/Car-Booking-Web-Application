<?php
	session_start();
	if(!isset($_SESSION["status"]))
	{
		header("location:index.php?log=0");	
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Rent a Car</title>
<link href="a1style.css" rel="stylesheet">
<style>
	.mySlides {display:none;}
	label.error 
	{
    color: red;
    }
	</style>
<style>
	.nounder
	{
		text-decoration:none;	
	}
	.nounder:hover
	{
		color:#0C6;	
	}
	a:link{ text-decoration:none; }
</style>
<link href="jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.datepicker.min.css" rel="stylesheet" type="text/css">
<script src="jQueryAssets/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="jQueryAssets/jquery-ui-1.9.2.datepicker.custom.min.js" type="text/javascript"></script>
<script src="js/jquery.validate.js" type="text/javascript"></script>
<script>
function myFunction() {
    var x = document.getElementById("vmenu");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}

$(document).ready(function() {
    	$.validator.addMethod("valueNotEquals", function(value, element, arg){
		  return arg != value;
		 }, "Value must not equal arg.");
		 
		 jQuery.validator.addMethod("lettersonly", function(value, element) {
		  return this.optional(element) || /^[a-z\s]+$/i.test(value);
		}, "Please type letters only"); 
		
	$("#form1").validate({
					rules: {
						pdate: { required:true },
						pplace: { required: true },
						ptime: {
							required:true
						
							
						},
						contact: { required: true, digits:true, maxlength:10 }
					
						
						
						
					},
					messages: {
						pdate: { required:"Enter picnic date" },
						pplace: { required:"Enter pick up place" },
						ptime: {
							required:"Enter pickup time"
						
							
						},
						
						contact: { required:"Enter contact no", digits:"Enter digits only", maxlengh:"Enter 10 digits only"}
						
						
	               
					}
					
			});
});
</script>
<script>
function myFunction() {
    var x = document.getElementById("vmenu");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
$(document).ready(function() {
    $("#Datepicker1").change(function() {
        var td=$(this).val();
		var cd = new Date();
		
		var startDay = new Date(td);
		var endDay = new Date(cd);
		var millisecondsPerDay = 1000 * 60 * 60 * 24;

		var millisBetween = startDay.getTime() - endDay.getTime();
		var days = millisBetween / millisecondsPerDay;
		if(days>7 || days<0)
		{
			alert("Invalid Date");
			$("#Datepicker1").val('');
			$("#Datepicker1").focus();	
		}
    });
});
</script>
</head>

<body>
<div class="a1-container a1-red a1-small a1-padding-8">
	<div class="a1-row">
    	<div class="a1-third">
        	<div class="a1-bar">
        		<span class="a1-bar-item">Phone : +91-9954425896 | Email : customercare@easyway.com</span>
            </div>
        </div>
        <div class="a1-rest">
        	<div class="a1-bar">
            	<a onclick="document.getElementById('id01').style.display='block'" class="a1-bar-item a1-hide-small nounder a1-right" style="cursor:pointer;">Track Booking</a>
            	<a href="contact.php" class="a1-bar-item a1-hide-small nounder a1-right">Contact Us</a>
                <a href="busforpicnic.php" class="a1-bar-item a1-hide-small nounder a1-right">Bus for Picnic</a>
                <a href="weddingcars.php" class="a1-bar-item a1-hide-small nounder a1-right">Wedding Cars</a>
                <a href="carrental.php" class="a1-bar-item a1-hide-small nounder a1-right">Car Rental</a>
            	<a href="index.php" class="a1-bar-item nounder a1-right">Home</a>
            </div>
        </div>
    </div>
	
</div>
<img src="images/car-rental.png" style="width:100%;"/>
<div class="a1-container a1-small" style="margin-top:20px; margin-bottom:20px;">
	<div class="a1-card-4 a1-small" style="margin:10px auto; width:800px;">
    	<div class="a1-container a1-blue a1-center">
        	<table width="100%" border="0" cellspacing="2" cellpadding="0">
        	  <tr>
        	    <td width="26%" align="left">Welcome
        	      <?php 
						if(isset($_SESSION["status"]))
						{
							echo $_SESSION["username"].' | <a href="logout.php">Logout</a>'; 
						}
						else
						{
							echo 'GUEST';	
						}
					?></td>
        	    <td width="74%" align="right"><h6>PICNIC PACKAGE BOOKING</h6></td>
      	    </tr>
      	  </table>
        </div>
        <div class="a1-container a1-light-gray a1-padding-8">
          <form id="form1" name="form1" method="post" action="propbook.php">
          		<table width="70%" border="0" align="center" cellpadding="0" cellspacing="2">
                 <tr>
                      <td height="35">Picnic place:</td>
                      <td><input name="place" type="text" required class="a1-input a1-border a1-round" id="place"value="<?php echo $_GET["place"];?>"readonly></td>
                    </tr>
                      <tr>
                      <td height="21">&nbsp;</td>
                      <td><span class="a1-red a1-tiny">You can book at most 7 days prior to your travel date</span></td>
                  </tr>
                    <tr>
                      <td width="29%" height="35">Picnic Date:</td>
                      <td width="71%"><input class="a1-input a1-border a1-round" type="text" id="Datepicker1" name="pdate"></td>
                    </tr>
                    
                    <tr>
                      <td height="35">Select Rate:</td>
                      <td><select class="a1-select a1-border a1-round" name="rate" id="rate">
                        <option value="default">---Select Rate---</option>
                        <option>Winger Rate</option>
                        <option>Bus Rate</option>
                         <option>Traveller Rate</option>
                      </select></td>
                    </tr>
                    <tr>
                      <td height="35">Deposit</td>
                      <td><input name="deposit" type="text" required class="a1-input a1-border a1-round" id="deposit"value="<?php echo $_GET["deposit"]; ?>" readonly></td>
                    </tr>
                    <tr>
                      <td height="35">Contact No:</td>
                      <td><input name="contact" type="text" required class="a1-input a1-border a1-round" id="contact"></td>
                    </tr>
                   <tr>
                      <td height="35">Pick up time:</td>
                      <td><input name="ptime" type="text" required class="a1-input a1-border a1-round" id="ptime"></td>
                    </tr>
                     <tr>
                      <td height="35">Pick up place:</td>
                      <td><input name="pplace" type="text" required class="a1-input a1-border a1-round" id="pplace"placeholder="Within Jorhat region"></td>
                    </tr>
                    <tr>
                      <td height="35">&nbsp;</td>
                      <td><input class="a1-btn-block a1-red" type="submit" name="submit" id="submit" value="Submit"></td>
                    </tr>
                  </table>
          </form>
      </div>
    </div>
</div>
<div class="a1-container a1-blue-gray a1-padding-16">
	<div style="float:left;">Copyright @ easyway cars</div>
    <div style="float:right;">
    	Designed By 
    </div>
</div>

<div class="a1-container">
  <div id="id01" class="a1-modal">
    <div class="a1-modal-content a1-card-4 a1-animate-zoom a1-pale-red" style="max-width:400px">

      <div class="a1-center"><br>
        <span onclick="document.getElementById('id01').style.display='none'" class="a1-button a1-pale-red a1-xlarge a1-hover-red a1-display-topright" title="Close Modal">&times;</span>
        <img src="images/magnifier.png" style="width:30%" class="a1-margin-top"><br>
		TRACK YOUR BOOKING
      </div>

      <form name="form3" id="form3" class="a1-container" method="post" action="tracknow.php">
        <div class="a1-section" style="padding-bottom:10px;">
          <label><b>Enter Booking ID</b></label>
          <input class="a1-input a1-border a1-round a1-margin-bottom" type="text" name="bid" required>
          <button class="a1-button a1-block a1-red a1-section a1-padding" type="submit" name="submit">Submit</button>
          
        </div>
      </form>
	
    </div>
  </div>
</div>
<script type="text/javascript">
$(function() {
	$( "#Datepicker1" ).datepicker(); 
});
</script>
</body>
</html>
<?php
	if(isset($_GET["ok"]))
	{
		echo '<script> alert("Registration Completed"); </script>';	
	}
?>