<?php
include "connect.php";
if(isset($_POST["submit"]))
{
	$name=$_POST["name"];
	$address=$_POST["address"];
	$gender=$_POST["gender"];
	$ph=$_POST["ph"];
	$mail=$_POST["mail"];
	$password=$_POST["password"];
	$cpassword=$_POST["cpassword"];
	$sql="insert into registration values(null,'$name','$address','$gender','$ph','$mail','$password','$cpassword')";
	$result=mysql_query($sql,$link);
	if($result)
	{
		header ("location:registration.php?ok=1");
	}
	else
	{
		echo mysql_error();
	}
}
?>