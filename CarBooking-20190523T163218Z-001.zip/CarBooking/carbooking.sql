/*
Navicat MySQL Data Transfer

Source Server         : con
Source Server Version : 50612
Source Host           : localhost:3306
Source Database       : carbooking

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2017-06-10 06:19:17
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `admin`
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `userid` varchar(20) NOT NULL,
  `password` varchar(15) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of admin
-- ----------------------------

-- ----------------------------
-- Table structure for `booking`
-- ----------------------------
DROP TABLE IF EXISTS `booking`;
CREATE TABLE `booking` (
  `bid` varchar(20) NOT NULL DEFAULT '',
  `bdate` date NOT NULL,
  `tdate` date NOT NULL,
  `cid` varchar(20) NOT NULL,
  `carmodel` varchar(20) NOT NULL,
  `mode` varchar(20) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `pickupplace` varchar(30) NOT NULL,
  `pickuptime` varchar(20) NOT NULL,
  `driver` int(11) NOT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of booking
-- ----------------------------
INSERT INTO `booking` VALUES ('Hat0609081713', '2017-06-09', '2017-06-17', 'doloi', 'Mahindra Scorpio', 'Per KM', '67788', 'podumoni', '8', '0', 'Pending');
INSERT INTO `booking` VALUES ('Hat0609083413', '2017-06-09', '2017-06-18', 'doloi', 'Mahindra Scorpio', 'default', '98721', 'kenduguri', '2pm', '0', 'Pending');
INSERT INTO `booking` VALUES ('Sed0609114651', '2017-06-09', '2017-06-18', 'pranjit', 'Indigo', 'Per Day', '795879583795', 'jorhat', '9am', '0', 'Pending');
INSERT INTO `booking` VALUES ('SUV0608043235', '2017-06-08', '2017-06-17', 'sabu', 'terrano', 'Per Day', '9954306155', 'kenduguri', '9am', '0', 'Pending');
INSERT INTO `booking` VALUES ('SUV0608051412', '2017-06-08', '2017-06-23', 'gitartha', 'Mahindra Scorpio', 'Per Day', '9085997819', 'pulibor', '2pm', '0', 'Pending');
INSERT INTO `booking` VALUES ('SUV0609115701', '2017-06-09', '2017-06-02', 'pranjit', 'Toyota Innova', 'Per Day', '666', 'hgjg', '5am', '0', 'Pending');

-- ----------------------------
-- Table structure for `cars`
-- ----------------------------
DROP TABLE IF EXISTS `cars`;
CREATE TABLE `cars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cartype` varchar(20) NOT NULL,
  `carmodel` varchar(20) NOT NULL,
  `ratekm` int(11) NOT NULL,
  `rateday` int(11) NOT NULL,
  `nightstay` int(11) DEFAULT NULL,
  `nop` int(11) NOT NULL,
  `photo` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of cars
-- ----------------------------
INSERT INTO `cars` VALUES ('3', 'Hatchback', 'Mahindra Scorpio', '30', '2500', '1000', '7', 'cars/5939f9dfefaea.jpg');
INSERT INTO `cars` VALUES ('4', 'SUV', 'Toyota Innova', '30', '3000', '1500', '11', 'cars/59383c3188f79.jpg');
INSERT INTO `cars` VALUES ('5', 'Sedan', 'Indigo', '20', '2000', '1000', '5', 'cars/59383ce85f834.jpg');
INSERT INTO `cars` VALUES ('6', 'Hatchback', 'Indica', '18', '1850', '900', '5', 'cars/5938902cb139a.jpg');
INSERT INTO `cars` VALUES ('10', 'SUV', 'terrano', '25', '3000', '40', '6', 'cars/593977fbdff58.jpg');

-- ----------------------------
-- Table structure for `drivers`
-- ----------------------------
DROP TABLE IF EXISTS `drivers`;
CREATE TABLE `drivers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `photo` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of drivers
-- ----------------------------
INSERT INTO `drivers` VALUES ('11', 'ankur bikakh', '64764764', 'drivers/593b3df68d235.jpg');

-- ----------------------------
-- Table structure for `login`
-- ----------------------------
DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of login
-- ----------------------------
INSERT INTO `login` VALUES ('admin', 'admin');
INSERT INTO `login` VALUES ('opera', '12345');

-- ----------------------------
-- Table structure for `passenger`
-- ----------------------------
DROP TABLE IF EXISTS `passenger`;
CREATE TABLE `passenger` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(15) NOT NULL,
  `address` varchar(40) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `idproof` varchar(50) NOT NULL,
  `userid` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of passenger
-- ----------------------------

-- ----------------------------
-- Table structure for `picnic`
-- ----------------------------
DROP TABLE IF EXISTS `picnic`;
CREATE TABLE `picnic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `place` varchar(40) NOT NULL,
  `rate35` int(11) NOT NULL,
  `rate42` int(11) NOT NULL,
  `ratetraveller` int(11) NOT NULL,
  `deposit` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of picnic
-- ----------------------------
INSERT INTO `picnic` VALUES ('1', 'nimatighat', '3500', '4500', '5500', '2000');

-- ----------------------------
-- Table structure for `picnicbooking`
-- ----------------------------
DROP TABLE IF EXISTS `picnicbooking`;
CREATE TABLE `picnicbooking` (
  `bid` varchar(11) NOT NULL DEFAULT '',
  `bdate` date NOT NULL,
  `pdate` date NOT NULL,
  `cid` varchar(10) NOT NULL,
  `ratetype` varchar(15) NOT NULL,
  `contact` int(11) NOT NULL,
  `pcncplace` varchar(10) NOT NULL,
  `pplace` varchar(10) NOT NULL,
  `ptime` varchar(10) NOT NULL,
  `deposit` int(11) NOT NULL,
  `driver` int(11) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of picnicbooking
-- ----------------------------
INSERT INTO `picnicbooking` VALUES ('1am061am', '2017-06-09', '2017-06-29', 'doloi', 'Bus Rate', '234566', 'nimatighat', 'barua char', '1am', '2000', '0', 'Pending');
INSERT INTO `picnicbooking` VALUES ('5am065am', '2017-06-09', '2017-06-01', 'gitartha', 'Traveller Rate', '987654321', 'nimatighat', 'science co', '5am', '2000', '0', 'Pending');
INSERT INTO `picnicbooking` VALUES ('6am066am', '2017-06-09', '2017-06-22', 'gitartha', 'default', '1111', 'nimatighat', 'dergaon', '6am', '4500', '0', 'Pending');

-- ----------------------------
-- Table structure for `tour`
-- ----------------------------
DROP TABLE IF EXISTS `tour`;
CREATE TABLE `tour` (
  `bookingid` varchar(20) NOT NULL,
  `car` varchar(20) NOT NULL,
  `carno.` varchar(15) NOT NULL,
  `driver` varchar(20) NOT NULL,
  `cotact` varchar(30) NOT NULL,
  PRIMARY KEY (`bookingid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tour
-- ----------------------------

-- ----------------------------
-- Table structure for `users`
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `name` varchar(40) NOT NULL,
  `age` int(11) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `address` varchar(30) NOT NULL,
  `phoneno` bigint(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('aminur', '22', 'Male', 'hjgdsj', '8657658', 'aminur', 'aminur');
INSERT INTO `users` VALUES ('ankur', '21', 'Male', 'kuralorguri', '8485898981', 'ankur', 'ankur');
INSERT INTO `users` VALUES ('Ashim Ranjan Bora', '37', 'Male', 'Na ALi, Jorhat', '9706261939', 'ashimrb', '12345');
INSERT INTO `users` VALUES ('ankur doloi', '21', 'Male', 'podumoni', '987654321', 'doloi', '098');
INSERT INTO `users` VALUES ('Gitartha Puzari', '20', 'Male', 'Jorhat', '9085997819', 'gitartha', '321');
INSERT INTO `users` VALUES ('pranjit dutta', '21', 'Female', 'lahdoigar', '88787877878', 'pranjit', 'pranjit');
INSERT INTO `users` VALUES ('Sandeep Chetia', '20', 'Male', 'teok', '12345678', 'sabu', 'sabu');
INSERT INTO `users` VALUES ('Sandeep Chetia', '10', 'Male', 'go you', '0', 'sandyman', 'sandeepchetia');

-- ----------------------------
-- Table structure for `wcarbooking`
-- ----------------------------
DROP TABLE IF EXISTS `wcarbooking`;
CREATE TABLE `wcarbooking` (
  `bid` varchar(11) NOT NULL DEFAULT '',
  `bdate` date NOT NULL,
  `wdate` date NOT NULL,
  `cid` varchar(11) NOT NULL,
  `cname` varchar(10) NOT NULL,
  `contact` int(11) NOT NULL,
  `driver` int(11) NOT NULL,
  `colour` varchar(10) NOT NULL,
  `cno` int(11) NOT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of wcarbooking
-- ----------------------------
INSERT INTO `wcarbooking` VALUES ('1230608', '2017-06-08', '2017-05-17', 'aminur', 'nano', '9011', '0', 'gray', '1234', null);
INSERT INTO `wcarbooking` VALUES ('2130609whit', '2017-06-09', '2017-06-30', 'doloi', 'xylo', '321111', '0', 'white', '2132', 'pending');
INSERT INTO `wcarbooking` VALUES ('3240608', '2017-06-08', '1970-01-01', '0', 'honda city', '898989', '0', 'gold', '3241', null);
INSERT INTO `wcarbooking` VALUES ('3450608', '2017-06-08', '1970-01-01', 'sabu', 'indigo man', '9991', '0', 'white', '3456', null);
INSERT INTO `wcarbooking` VALUES ('5010608gree', '2017-06-08', '2017-06-25', 'ankur', 'ciaz', '1', '0', 'green', '5013', 'pending');
INSERT INTO `wcarbooking` VALUES ('7890608', '2017-06-08', '2017-06-03', 'ankur', 'manza', '8811', '0', 'gray', '7898', 'pending');
INSERT INTO `wcarbooking` VALUES ('9090609gold', '2017-06-09', '2017-06-24', 'pranjit', 'manza', '2147483647', '0', 'gold', '9098', 'pending');

-- ----------------------------
-- Table structure for `wedding`
-- ----------------------------
DROP TABLE IF EXISTS `wedding`;
CREATE TABLE `wedding` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `car` varchar(30) NOT NULL,
  `No` varchar(10) NOT NULL,
  `color` varchar(20) NOT NULL,
  `rate` int(11) NOT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of wedding
-- ----------------------------
INSERT INTO `wedding` VALUES ('10', 'xylo', '2132', 'white', '5000', '0');
INSERT INTO `wedding` VALUES ('2', 'swift dzire', '7777', 'gold', '3000', '0');
INSERT INTO `wedding` VALUES ('4', 'manza', '9098', 'gold', '4000', '0');
INSERT INTO `wedding` VALUES ('5', 'alto 800', '3456', 'white', '5000', '0');
