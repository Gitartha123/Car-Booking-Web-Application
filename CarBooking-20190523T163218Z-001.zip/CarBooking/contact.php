<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link href="a1style.css" type="text/css" rel="stylesheet"/>
</head>

<body>
<div class="a1-container a1-red a1-small a1-padding-8">
	<div class="a1-row">
    	<div class="a1-third">
        	<div class="a1-bar">
        		<span class="a1-bar-item">Phone :+91-9954425896 | Email : customercare@easyway.com</span>
            </div>
        </div>
        <div class="a1-rest">
        	<div class="a1-bar">
            	<a onclick="document.getElementById('id01').style.display='block'" class="a1-bar-item a1-hide-small nounder a1-right" style="cursor:pointer;">Track Booking</a>
            	<a href="contact.php" class="a1-bar-item a1-hide-small nounder a1-right">Contact Us</a>
                <a href="busforpicnic.php" class="a1-bar-item a1-hide-small nounder a1-right">Bus for Picnic</a>
                <a href="weddingcars.php" class="a1-bar-item a1-hide-small nounder a1-right">Wedding Cars</a>
                <a href="carrental.php" class="a1-bar-item a1-hide-small nounder a1-right">Car Rental</a>
            	<a href="index.php" class="a1-bar-item nounder a1-right">Home</a>
            </div>
        </div>
    </div>
	
</div>
<img src="images/car-rental.png" style="width:100%;"/>
<h1><b><span style="color:#C00">Contact us @</span></b></h1>
  <div class="a1-container"><div class="a1-row-padding"> <marquee align="left"><h3><b><i><span style="font-size:20px; color:#F00">Mobile No:9085997819 |
   Whats App number:9954306155 |
   Email id: customercare@easyway.com |
   </span><i></b></h3></marquee></div></div>
</body>
</html>