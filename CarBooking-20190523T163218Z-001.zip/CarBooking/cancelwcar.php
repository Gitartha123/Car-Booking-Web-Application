<?php
	include "connect.php";
    $id=$_GET["bid"];
	mysql_query("update wcarbooking set status='Cancelled' where bid='$id'");
	header("location:mywcarbooking.php");
?>