<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link href="a1style.css" type="text/css" rel="stylesheet"/>
<style>
	.nounder
	{
		text-decoration:none;	
	}
	.nounder:hover
	{
		color:#0C6;	
	}
</style>
<script>
function myFunction() {
    var x = document.getElementById("vmenu");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}

</script>
</head>

<body>
<div class="a1-container a1-red a1-small a1-padding-8">
	<div class="a1-row">
    	<div class="a1-half">
        	<div class="a1-bar">
        		<span class="a1-bar-item">Phone : +91-9954425896 | Email : customercare@easyway.com</span>
                <P align="center">ADMIN PANNEL</P></div>
        </div>
        <div class="a1-half">
        	<div class="a1-bar">
            	<p><a href="#" class="a1-bar-item nounder"><i class="fa fa-home"></i>Add cars</a>
            	  <a href="#" class="a1-bar-item a1-hide-small nounder">Add tour</a>
            	  <a href="#" class="a1-bar-item a1-hide-small nounder">Registered members</a>
            	  <a href="#" class="a1-bar-item a1-hide-small nounder">View booking</a>
            	  <a href="#" class="a1-bar-item a1-hide-small nounder">Add wedding cars</a>
            	  <a href="#" class="a1-bar-item a1-hide-small nounder"><img src="pics/begin_icon_compact.png"/></a></p>
            	
            	  <a href="javascript:void(0)" class="a1-bar-item a1-button a1-right a1-hide-large a1-hide-medium" onclick="myFunction()">&#9776;</a></p>
            </div>
        </div>
    </div>
	
</div>
<img src="images/car-rental.png" style="width:100%;"/>
<div class="a1-container a1-small" style="margin-top:20px; margin-bottom:20px;">
	<div class="a1-card-4 a1-light-gray" style="width:500px; margin:30px auto;">
   	  <div class="a1-container a1-blue">
        	<h6>ADD NEW WEDDING CAR</h6>
        </div>
        <div class="a1-container a1-padding-12">
          <form method="post" name="form1" id="form1"action="addwdcar.php">
            <table width="100%" border="0" cellspacing="2" cellpadding="1">
              <tr>
                <td width="38%">CARTYPE:</td>
                <td width="62%">
                  <select class="a1-select" name="cartype" id="cartype">
                    	      <option>-----Select Car Type-----</option>
                    	      <option>SUV</option>
                    	      <option>Sedan</option>
                    	      <option>Hatchback</option>
                    	      <option>Van</option>
                    	      <option>Others</option>
       	        </select></td>
              </tr>
              <tr>
                <td>CARNAME:</td>
                <td><input class="a1-input a1-border a1-round"type="text" name="carname" id="carname"></td>
              </tr>
              <tr>
                <td>PRICE:</td>
                <td><input class="a1-input a1-border a1-round" type="text" name="carprice" id="carprice"></td>
              </tr>
              <tr>
                <td>ADVANCE:</td>
                <td><input class="a1-input a1-border a1-round" type="text" name="advance" id="advance"></td>
              </tr>
              <tr>
                <td>IMAGE:</td>
                <td><input class="a1-input a1-border a1-round"type="file" name="image" id="image"></td>
              </tr>
              <tr>
                <td height="48">&nbsp;</td>
                <td><input class="a1-btn-block a1-red" type="submit" name="submit" id="submit" value="Submit"></td>
              </tr>
            </table>
          </form>
        </div>
    </div>
</div>
<div class="a1-container a1-blue-gray a1-padding-16">
	<div style="float:left;">Copyright @ easyway cars</div>
    <div style="float:right;">
    	Designed By 
    </div>
</div>

</body>
</html>
<?php
if(isset($_GET["ok"]))
{
	echo '<script>alert("submitted succesfully");</script>';
}
?>