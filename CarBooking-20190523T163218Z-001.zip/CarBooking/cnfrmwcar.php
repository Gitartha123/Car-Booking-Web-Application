<?php
	include "connect.php";
	$id=$_GET["id"];
	mysql_query("update wcarbooking set status='Confirmed' where bid='$id'");
	header("location:viewwcarbooking.php");
?>