<?php
include "connect.php";
if(isset($_POST["submit"]))
{
	$place=$_POST["place"];
	$rate35=$_POST["rate35"];
	$rate42=$_POST["rate42"];
	$trate=$_POST["trate"];
	$deposit=$_POST["deposit"];
	$sql="insert into picnic values(null,'$place','$rate35','$rate42','$trate','$deposit')";
	$result=mysql_query($sql,$link);
	if($result)
	{
		header("location:picnicentry.php?ok=1");
	}
	else
	{
		echo mysql_error();
	}
}
?>

	