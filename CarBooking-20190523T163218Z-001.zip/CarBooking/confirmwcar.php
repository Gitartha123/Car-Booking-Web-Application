<?php
	include "connect.php";
	$bid=$_GET["bid"];
	$result=mysql_query("Update wcarbooking set status='Confirmed' where bid='$bid'");
	if($result)
	{
		header("location:viewwcarbooking.php");	
	}
?>