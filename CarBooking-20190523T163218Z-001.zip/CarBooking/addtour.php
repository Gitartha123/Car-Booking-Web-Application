<?php
include "connect.php";
if(isset($_POST["submit"]))
{
	$tourname=$_POST["tourname"];
	$duration=$_POST["duration"];
	$hbrate=$_POST["hbrate"];
	$srate=$_POST["srate"];
	$suvrate=$_POST["suvrate"];
	$advance=$_POST["advance"];
	$details=$_POST["details"];
	$image=$_POST["image"];
	$sql="insert into Tour values(null,'$tourname','$duration','$hbrate','$srate','$suvrate','$advance','$details','$image')";
	$result=mysql_query($sql,$link);
	if($result)
	{
		header("location:touradd.php?ok=1");
	}
	else
	{
		echo mysql_error();
	}
}
?>

