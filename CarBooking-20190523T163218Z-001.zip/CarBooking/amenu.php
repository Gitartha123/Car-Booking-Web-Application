<a href="#" class="a1-bar-item nounder">Welcome Admin</a>
<a href="adminhome.php" class="a1-bar-item nounder">Admin Home</a>
<div class="a1-dropdown-hover">
    <button class="a1-button a1-hover-red">Enter Records</button>
    <div class="a1-dropdown-content a1-bar-block a1-card-4 a1-red" style="width:100px;">
      <a href="carEntry.php" class="a1-bar-item a1-button a1-hover-yellow">Car Entry</a>
      <a href="driverentry.php" class="a1-bar-item a1-button a1-hover-yellow">Driver Entry</a>
      <a href="picnicentry.php" class="a1-bar-item a1-button a1-hover-yellow">Picnic Package</a>
      <a href="wcarentry.php" class="a1-bar-item a1-button a1-hover-yellow">Wedding Car</a>
    </div>
</div>
<div class="a1-dropdown-hover">
    <button class="a1-button a1-hover-red">Display Records</button>
    <div class="a1-dropdown-content a1-bar-block a1-card-4 a1-red" style="width:180px;">
      <a href="viewcar.php" class="a1-bar-item a1-button a1-hover-yellow">Cars</a>
      <a href="viewdriver.php" class="a1-bar-item a1-button a1-hover-yellow">Drivers</a>
      <a href="viewpicnic.php" class="a1-bar-item a1-button a1-hover-yellow">Picnic Packages</a>
      <a href="wcarview.php" class="a1-bar-item a1-button a1-hover-yellow">Wedding Cars</a>
      <span class="a1-bar-item a1-button a1-hover-red">------------</span>
      <a href="viewcarbooking.php" class="a1-bar-item a1-button a1-hover-yellow">Car Booking</a>
      <a href="viewwcarbooking.php" class="a1-bar-item a1-button a1-hover-yellow">Wedding Car Booking</a>
      <a href="viewpicnicbooking.php" class="a1-bar-item a1-button a1-hover-yellow">Picnic Package Booking</a>
    </div>
</div>
<a href="viewmember.php" class="a1-bar-item a1-hide-small nounder">Members</a>
<a href="logout.php" class="a1-bar-item a1-hide-small nounder">Logout</a>