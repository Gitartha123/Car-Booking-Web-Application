<?php
	include "connect.php";
	$id=$_GET["cid"];
	mysql_query("delete from picnic where id='$id'");
	header("location:viewpicnic.php");
?>