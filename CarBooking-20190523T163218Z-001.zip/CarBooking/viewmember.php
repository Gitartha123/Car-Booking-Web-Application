<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Rent a Car</title>
<link href="a1style.css" rel="stylesheet">
<style>
	.nounder
	{
		text-decoration:none;	
	}
	.nounder:hover
	{
		color:#0C6;	
	}
</style>
<script>
function myFunction() {
    var x = document.getElementById("vmenu");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
function condel()
{
	return confirm("Are you sure?");	
}
</script>
</head>

<body>
<div class="a1-container a1-red a1-small a1-padding-8">
	<div class="a1-row">
    	<div class="a1-half">
        	<div class="a1-bar">
        		<span class="a1-bar-item">Phone : +91-9954425896 | Email : customercare@easyway.com</span>
            </div>
        </div>
        <div class="a1-half">
        	<div class="a1-bar">
            	<?php include "amenu.php"; ?>
            </div>
        </div>
    </div>
	
</div>
<img src="images/car-rental.png" style="width:100%;"/>
<div class="a1-container a1-small" style="margin-top:20px; margin-bottom:20px;">
	<div class="a1-card" style="width:1000px; margin:0 auto;">
	  <div class="a1-container a1-blue-gray">
      	<h6>View Members</h6>
      </div>
      <div class="a1-container a1-small a1-padding-12">
        			<table class="a1-table-all" width="100%">
                	    <tr class="a1-blue-gray">
                	      <td>Passenger name:</td>
                	      <td>Gender:</td>
                	      <td>Address:</td>
                	      <td>Age:</td>
                	      <td>User id:</td>
                	     
                	      <td>&nbsp;</td>
              	      </tr>
                      <?php
					  	include "connect.php";
						$result=mysql_query("Select * from users");	
						while($row=mysql_fetch_array($result))
						{
							echo '<tr>';
							echo '<td>'.$row["name"].'</td>';
							echo '<td>'.$row["sex"].'</td>';
							echo '<td>'.$row["address"].'</td>';
							echo '<td>'.$row["age"].'</td>';
							echo '<td>'.$row["username"].'</td>';
							
							
							echo '<td><a class="a1-btn a1-green a1-round" href="delmember.php?username='.$row[5].'" onClick="return condel();">Delete Member</a></td>';
							echo '</tr>';
						}
					  ?>
              	    </table>
      </div>
      
  </div>
</div>