<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Rent a Car</title>
<link href="a1style.css" rel="stylesheet">
<style>
	.mySlides {display:none;}
	label.error 
	{
    color: white;
    }
</style>
<style>
	.nounder
	{
		text-decoration:none;	
	}
	.nounder:hover
	{
		color:#0C6;	
	}
</style>
<script src="jQueryAssets/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="jQueryAssets/jquery-ui-1.9.2.datepicker.custom.min.js" type="text/javascript"></script>
<script src="js/jquery.validate.js" type="text/javascript"></script>
<script>
function myFunction() {
    var x = document.getElementById("vmenu");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
$(document).ready(function() {
	$.validator.addMethod("valueNotEquals", function(value, element, arg){
		  return arg != value;
		 }, "Value must not equal arg.");
		 
		 jQuery.validator.addMethod("lettersonly", function(value, element) {
		  return this.optional(element) || /^[a-z\s]+$/i.test(value);
		}, "Please type letters only"); 
		
    $("#form1").validate({
					rules: {
						fname: {  required:true, lettersonly:true, maxlength:15 },
						sex: { required: true },
						age: { required: true, digits:true, maxlength:2 },
						addr: {
							required:true
							
						},
						contact: { required: true, digits:true, maxlength:10 },
						username: { required: true },
						password: { required: true ,minlength:5},
						pasword2: { required: true,equalTo:"#password" }
						
					},
					messages: {
						fname: { required:"Enter your name" , lettersonly:"Enter letters only", maxlength:"Enter max 15 letters"},
						sex: { required:" Enter sex" },
						age: { required:" Enter Your age", digits:"Enter digits only",maxlength:"Enter max 2 digits" },
						addr: {
							required:" Enter Your address" 
						},
						contact: { required:"Enter your contact no", digits:"Enter digits only", maxlength:"Enter your 10 digits mobile no" },
						username: { required:"Enter username" },
						
						pasword2: { required:"Enter same password again",equalTo:"password not matching" },
	               
					}
				});
});
</script>
</head>

<body>
<div class="a1-container a1-red a1-small a1-padding-8">
	<div class="a1-row">
    	<div class="a1-half">
        	<div class="a1-bar">
        		<span class="a1-bar-item">Phone : +91-9954425896 | Email : customercare@easyway.com</span>
            </div>
        </div>
        <div class="a1-half">
        	<div class="a1-bar">
            	<a href="#" class="a1-bar-item nounder"><i class="fa fa-home"></i>Home</a>
                <a href="#" class="a1-bar-item a1-hide-small nounder">Car Rental Packages</a>
                <a href="#" class="a1-bar-item a1-hide-small nounder">Wedding Cars</a>
                <a href="#" class="a1-bar-item a1-hide-small nounder">Bus Hire for Picnic</a>
                <a href="#" class="a1-bar-item a1-hide-small nounder">Contact Us</a>
                <a href="javascript:void(0)" class="a1-bar-item a1-button a1-right a1-hide-large a1-hide-medium" onclick="myFunction()">&#9776;</a>
            </div>
        </div>
    </div>
	
</div>
<img src="images/car-rental.png" style="width:100%;"/>
<div class="a1-container a1-small" style="margin-top:20px; margin-bottom:20px;">
	<div class="a1-card a1-gray" style="width:500px; margin:0 auto;">
	  <div class="a1-container a1-blue-gray">
      	<h6>REGISTER ACCOUNT</h6>
      </div>
      <form class="a1-container" name="form1" id="form1" method="post" action="proreg.php">
        	<p>
        	  <label>FULL NAME:</label>
              <input class="a1-input a1-border-blue" type="text" name="fname" id="fname">
        	</p>
          <p>
            <label>SEX:</label>
            <select class="a1-select a1-border-blue" name="sex" id="sex">
              <option selected="selected">Select</option>
              <option>Male</option>
              <option>Female</option>
            </select>
            </p>
            <p>
              <label>AGE:</label>
              <input class="a1-input a1-border-blue" type="text" name="age" id="age">
            </p>
            <p>
              <label>ADDRESS:</label>
              <input class="a1-input a1-border-blue" type="text" name="addr" id="addr">
            </p>
            <p>
              <label>PHONE NO:</label>
              <input class="a1-input a1-border-blue" type="text" name="contact" id="contact">
            </p>
            <p>
              <label>CHOOSE USER NAME:</label>
              <input class="a1-input a1-border-blue" type="text" name="username" id="username">
            </p>
            <p>
              <label>CHOOSE PASSWORD:</label>
              <input class="a1-input a1-border-blue" type="password" name="password" id="password">
            </p>
            <p>
              <label>RE-TYPE PASSWORD:</label>
              <input class="a1-input a1-border-blue" type="password" name="pasword2" id="pasword2">
            </p>
            <p align="center">
              <input class="a1-btn-block a1-blue" type="submit" name="submit" id="submit" value="Register Now">
            </p>
         </form>
	</div>
</div>
<div class="a1-container a1-blue-gray a1-padding-16">
	<div style="float:left;">Copyright @ easyway cars</div>
    <div style="float:right;">
    	Designed By 
    </div>
</div>
</body>
</html>
