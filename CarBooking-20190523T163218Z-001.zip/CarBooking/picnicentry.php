<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link href="a1style.css" type="text/css" rel="stylesheet"/>
<style>
	.mySlides {display:none;}
	label.error 
	{
    color: red;
    }
	</style>
<style>
	.nounder
	{
		text-decoration:none;	
	}
	.nounder:hover
	{
		color:#0C6;	
	}
</style>
<script src="jQueryAssets/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="jQueryAssets/jquery-ui-1.9.2.datepicker.custom.min.js" type="text/javascript"></script>
<script src="js/jquery.validate.js" type="text/javascript"></script>
<script>
function myFunction() {
    var x = document.getElementById("vmenu");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
$(document).ready(function() {
    	$.validator.addMethod("valueNotEquals", function(value, element, arg){
		  return arg != value;
		 }, "Value must not equal arg.");
		 
		 jQuery.validator.addMethod("lettersonly", function(value, element) {
		  return this.optional(element) || /^[a-z\s]+$/i.test(value);
		}, "Please type letters only"); 
		
	$("#form1").validate({
					rules: {
						place: { required: true, lettersonly:true,   },
						rate35: { required: true, digits: true },
						
						rate42: {
							required:true,
							digits:true
						},
						
						trate:{ required:true, digits:true },
						deposit:{required:true, digits:true }
						
					},
					messages: {
						place: { required:"Enter picnic place", lettersonly:"Enter letters only"  },
						rate35: { required:"Enter rate", digits:"Enter digits only" },
					
						rate42: {
							required:"Enter rate",
							digits:"Enter digits only"
							
						},
						
						trate: {
							required:"Enter rate",
							digits:"Enter digits only"
							
						},
						deposit:{required:"Enter deposit", digits:"Enter digits only" }
	               
					}
			});
});
</script>
</head>

<body>
<div class="a1-container a1-red a1-small a1-padding-8">
	<div class="a1-row">
    	<div class="a1-half">
        	<div class="a1-bar">
        		<span class="a1-bar-item">Phone : +91-9954425896 | Email : customercare@easyway.com</span>
                <P align="center">&nbsp;</P></div>
        </div>
        <div class="a1-half">
        	<div class="a1-bar">
            	<?php include "amenu.php"; ?>
            </div>
        </div>
    </div>
	
</div>
<img src="images/car-rental.png" style="width:100%;"/>
<div class="a1-container a1-small" style="margin-top:20px; margin-bottom:20px;">
	<div class="a1-card-4 a1-light-gray" style="width:500px; margin:30px auto;">
   	  <div class="a1-container a1-blue">
        	<h6>ADD PICNIC</h6>
        </div>
        <div class="a1-container a1-padding-12">
          <form action="addpicnic.php" method="post"  name="form1" id="form1">
            <table width="100%" border="0" cellspacing="2" cellpadding="1">
              <tr>
                <td width="38%">PLACE:</td>
                <td width="62%"><input class="a1-input a1-border a1-round"type="text" name="place" id="place"></td>
              </tr>
              <tr>
                <td>WINGER RATE:</td>
                <td><input class="a1-input a1-border a1-round" type="text" name="rate35" id="rate35"></td>
              </tr>
              <tr>
                <td>TATA SUMO RATE:</td>
                <td><input class="a1-input a1-border a1-round" type="text" name="rate42" id="rate42"></td>
              </tr>
              <tr>
                <td>TRAVELLER RATE:</td>
                <td><input class="a1-input a1-border a1-round" type="text" name="trate" id="trate"></td>
              </tr>
              <tr>
                <td>DEPOSIT:</td>
                <td><input class="a1-input a1-border a1-round" type="text" name="deposit" id="deposit"></td>
              </tr>
              <tr>
                <td height="48">&nbsp;</td>
                <td><input class="a1-btn-block a1-red" type="submit" name="submit" id="submit" value="Submit"></td>
              </tr>
            </table>
          </form>
        </div>
    </div>
</div>
<div class="a1-container a1-blue-gray a1-padding-16">
	<div style="float:left;">Copyright @ easyway cars</div>
    <div style="float:right;">
    	Designed By Gitartha Puzari & Pranjit Dutta
    </div>
</div>

</body>
</html>
<?php
if(isset($_GET["ok"]))
{
	echo '<script>alert("submitted succesfully");</script>';
}
?>