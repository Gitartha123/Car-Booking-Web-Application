<?php
$link=@mysql_connect("localhost","root","") or die("unable to connect");
mysql_select_db("carbooking",$link) or die("cannot connect to database");
?>