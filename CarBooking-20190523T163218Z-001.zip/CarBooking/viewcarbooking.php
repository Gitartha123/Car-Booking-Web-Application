<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Rent a Car</title>
<link href="a1style.css" rel="stylesheet">
<style>
	.nounder
	{
		text-decoration:none;	
	}
	.nounder:hover
	{
		color:#0C6;	
	}
</style>
<link href="jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css">
<link href="jQueryAssets/jquery.ui.datepicker.min.css" rel="stylesheet" type="text/css">
<script src="jQueryAssets/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="jQueryAssets/jquery-ui-1.9.2.datepicker.custom.min.js" type="text/javascript"></script>
<script>
function myFunction() {
    var x = document.getElementById("vmenu");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}

</script>
</head>

<body>
<div class="a1-container a1-red a1-small a1-padding-8">
	<div class="a1-row">
    	<div class="a1-half">
        	<div class="a1-bar">
        		<span class="a1-bar-item">Phone : +91-9954425896 | Email : customercare@easyway.com</span>
            </div>
        </div>
        <div class="a1-half">
        	<div class="a1-bar">
            	<?php include "amenu.php"; ?>
            </div>
        </div>
    </div>
	
</div>
<img src="images/car-rental.png" style="width:100%;"/>
<div class="a1-container a1-small" style="margin-top:20px; margin-bottom:20px;">
	<div class="a1-card" style="width:1300px; margin:0 auto;">
	  <div class="a1-container a1-blue-gray">
      	<h6>View Car Booking</h6>
      </div>
       <div class="a1-row-padding">
<div class="a1-quarter">
<div class="a1-container a1-light-gray a1-padding-4">
  <form id="form1" name="form1" method="post">
 <p> 
   <input type="text" id="Datepicker1"name="date"placeholder="search travel date"class="a1 input">
 </p>
                <p align="right">
                <input class="a1-btn a1-green a1-round" type="submit" name="submit" id="submit" value="Search">
                <a href="viewcarbooking.php"> <input class="a1-btn a1-green a1-round"type="button" name="refresh" id="refresh" value="Refresh">
          </a></p>
                </form>
</div> 
</div>
      <div class="a1-rest"><div class="a1-container a1-small a1-padding-12">
        <table class="a1-table-all" width="100%" border="0" cellspacing="2" cellpadding="0">
      		    <tr class="a1-blue-gray">
      		      <td>Book Date</td>
      		      <td>Travel Date</td>
      		      <td>Car</td>
      		      <td>Mode</td>
      		      <td>Contact</td>
      		      <td>Pickup Place</td>
      		      <td>Pickup Time</td>
      		      <td>User</td>
      		      <td>&nbsp;</td>
   		        </tr>
                <?php
					include "connect.php";
					if(isset($_POST["submit"]))
					{
						$Datepicker1=$_POST["date"];
						$result=mysql_query("select * from booking where tdate='$Datepicker1'");
					}
					else
					{
						
					$result=mysql_query("Select * from booking");
					}
					while($row=mysql_fetch_array($result))
					{
						echo '<tr>';
						echo '<td>'.$row["bdate"].'</td>';
						echo '<td>'.$row["tdate"].'</td>';
						echo '<td>'.$row["carmodel"].'</td>';
						echo '<td>'.$row["mode"].'</td>';
						echo '<td>'.$row["contact"].'</td>';
						echo '<td>'.$row["pickupplace"].'</td>';
						echo '<td>'.$row["pickuptime"].'</td>';
						echo '<td>'.$row["cid"].'</td>';
						if($row["status"]=="Pending")
						{
							echo '<td><a class="a1-btn a1-red" href="cbooking.php?bid='.$row[0].'">Take Action</a></td>';
						}
						else
						{
							echo '<td>'.$row["status"].'</td>';
						}
						echo '</tr>';
					}
				?>
	    </table>
      </div>
      
  </div>
</div></div>
<div class="a1-container a1-blue-gray a1-padding-16">
	<div style="float:left;">Copyright @ easyway cars</div>
    <div style="float:right;">
    	Designed By 
    </div>
</div>
<script type="text/javascript">
$(function() {
	$( "#Datepicker1" ).datepicker({
		dateFormat:"yy-mm-dd"
	}); 
});
</script>
</body>
</html>
