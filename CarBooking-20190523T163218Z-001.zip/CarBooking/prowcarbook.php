<?php
	session_start();
	include "connect.php";
	if(isset($_POST["submit"]))
	{
		$td=mysql_real_escape_string($_POST["wdate"]);
		$wdate=date("Y-m-d",strtotime($td));
		$cname=$_POST["cname"];
		$cno=$_POST["cno"];
	    $bdate=date("Y-m-d");
		$contact=$_POST["contact"];
		$colour=$_POST["colour"];
		$bid=substr($cno,0,3).substr($bdate,5,2).substr($bdate,8,2).$contact;
		$cid=$_SESSION["username"];
		$wedplace=$_POST["wedplace"];
		$sql="insert into wcarbooking values('$bid','$bdate','$wdate','$cid','$cname','$contact',0,'$colour','$wedplace','$cno','pending')";
		$result=mysql_query($sql);
		if($result)
		{
			header("location:userhome.php?bid=".$bid);
		}
		else
		{
			echo mysql_error();	
		}
	}
?>