<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Rent a Car</title>
<link href="a1style.css" rel="stylesheet">
<style>
	.nounder
	{
		text-decoration:none;	
	}
	.nounder:hover
	{
		color:#0C6;	
	}
</style>
<script>
function myFunction() {
    var x = document.getElementById("vmenu");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}

</script>
</head>

<body>
<div class="a1-container a1-red a1-small a1-padding-8">
	<div class="a1-row">
    	<div class="a1-half">
        	<div class="a1-bar">
        		<span class="a1-bar-item">Phone : +91-9954425896 | Email : customercare@easyway.com</span>
            </div>
        </div>
        <div class="a1-half">
        	<div class="a1-bar">
            	<?php include "amenu.php"; ?>
            </div>
        </div>
    </div>
	
</div>
<img src="images/car-rental.png" style="width:100%;"/>
<!--<div class="a1-container a1-small" style="margin-top:20px; margin-bottom:20px;">
	<div class="a1-card-16 a1-modal-content " style="width:600px; margin:0 auto;">
    	<div class=" a1-center a1-container a1-green a1-center a1-animate-zoom">
            <br>
        <span onclick="document.getElementById('id01').style.display='none'" class="a1-button a1-pale-red a1-xlarge a1-hover-red a1-display-topright" title="Close Modal">&times;</span>
        	<h4><strong>Change Password</strong></h4><div class="a1-card-4 a1-light-gray a1-animate-zoom" style="width:500px; margin:30px auto;">
        <div class="a1-container a1-padding-12">
        </div>-->
        <div class="a1-container">
  <div id="id01" class="a1-modal">
    <div class="a1-modal-content a1-card-4 a1-animate-zoom a1-pale-red" style="max-width:400px">

      <div class="a1-center"><br>
        <span onclick="document.getElementById('id01').style.display='none'" class="a1-button a1-pale-red a1-xlarge a1-hover-red a1-display-topright" title="Close Modal">&times;</span>
        <img src="images/magnifier.png" style="width:30%" class="a1-margin-top"><br>
		TRACK YOUR BOOKING
      </div>
    	<form action="prochpass.php" method="post" enctype="multipart/form-data"  name="form1" id="form1">
            
            <table width="100%" border="0" cellspacing="2" cellpadding="1">
            	<?php
					session_start();
					include "connect.php";
					$id=$_SESSION["username"];
					$result=mysql_query("Select * from users where username='$id'");
					$row=mysql_fetch_array($result);
				?>
              <tr>
                  <td width="38%">USER ID</td>
                  <td width="62%"><input class="w3-input w3-border w3-round" type="text" name="username" id="username" value="<?php echo $row["username"]; ?>"></td>
              </tr>
              <tr>
                <td valign="top">New Password:</td>
                <td><input class="w3-input w3-border w3-round" type="password" name="password" id="password"></td>
              </tr>
              <tr>
                <td valign="top">Confirm Password:</td>
                <td><input class="w3-input w3-border w3-round" type="password" name="password2" id="password2"></td>
              </tr>
              <tr>
                <td height="48">&nbsp;</td>
                <td><input class="w3-btn  w3-red" type="submit" name="submit" id="submit" value="Update"></td>
              </tr>
            </table>
          </form>
        </div>
    </div>&nbsp;    	  </p>
    	</form>
	</div>
</div>
<div class="a1-container a1-blue-gray a1-padding-16">
	<div style="float:left;">Copyright @ easyway cars</div>
    <div style="float:right;">
    	Designed By 
    </div>
</div>
</body>
</html>
