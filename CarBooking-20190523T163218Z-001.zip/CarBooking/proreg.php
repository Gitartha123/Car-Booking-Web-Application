<?php
	include "connect.php";
	if(isset($_POST["submit"]))
	{
		$name=$_POST["fname"];
		$age=$_POST["age"];
		$sex=$_POST["sex"];
		$addr=$_POST["addr"];
		$contact=$_POST["contact"];
		$username=$_POST["username"];
		$pwd=$_POST["password"];
				
		$sql1="Select * from users where username='$username'";
		$result1=mysql_query($sql1);
		$n=mysql_num_rows($result1);
		if($n>0)
		{
			header("location:registration.php?d=1");
			return;
		}
		
		
		$sql="insert into users values('$name','$age','$sex','$addr','$contact','$username','$pwd')";
		$result=mysql_query($sql);
		if($result)
		{
			header("location:index.php?ok=1");
		}
		else
		{
			echo mysql_error();	
		}
	}
?>