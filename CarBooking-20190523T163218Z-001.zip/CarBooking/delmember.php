<?php
	include "connect.php";
	$username=$_GET["username"];
	mysql_query("delete from users where username='$username'");
	header("location:viewmember.php");
?>