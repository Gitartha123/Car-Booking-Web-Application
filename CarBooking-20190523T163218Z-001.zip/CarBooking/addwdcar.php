<?php
include "connect.php";
if(isset($_POST["submit"]))
{
	$cname=$_POST["cname"];
	$cno=$_POST["cno"];
	$colour=$_POST["select"];
	$rate=$_POST["rate"];
		$target_dir = "wedding/";
	$file = $target_dir . basename($_FILES["file1"]["name"]);
	
	$fileData = pathinfo(basename($_FILES["file1"]["name"]));
	
			
	$fileName = uniqid() . '.' . $fileData['extension'];
	$target_path = "wedding/" . $fileName;
		
	while(file_exists($target_path))
	{
		$fileName = uniqid() . '.' . $fileData['extension'];
		$target_path = "wedding/" . $fileName;
	}
	move_uploaded_file($_FILES["file1"]["tmp_name"], $target_path);
	
	$image="wedding/" . $fileName;
	//echo $image;
	$sql="insert into wedding values(null,'$cname','$cno','$colour','$rate',0)";
	$result=mysql_query($sql,$link);
	if($result)
	{
		header("location:wcarentry.php?ok=1");
	}
	else
	   {
	   echo mysql_error();
	   }
}
?>
	   