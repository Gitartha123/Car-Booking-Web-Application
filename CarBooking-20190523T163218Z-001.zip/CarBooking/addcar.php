<?php
include "connect.php";
if(isset($_POST["submit"]))
{
	$cartype=$_POST["selectype"];
	$carname=$_POST["carname"];
	$farekm=$_POST["farekm"];
	$fareday=$_POST["fareday"];
	$ntsty=$_POST["ntsty"];
	$nop=$_POST["nop"];
	
	$target_dir = "cars/";
	$file = $target_dir . basename($_FILES["file1"]["name"]);
	
	$fileData = pathinfo(basename($_FILES["file1"]["name"]));
	
			
	$fileName = uniqid() . '.' . $fileData['extension'];
	$target_path = "cars/" . $fileName;
		
	while(file_exists($target_path))
	{
		$fileName = uniqid() . '.' . $fileData['extension'];
		$target_path = "cars/" . $fileName;
	}
	move_uploaded_file($_FILES["file1"]["tmp_name"], $target_path);
	
	$image="cars/" . $fileName;
	//echo $image;
	$sql="insert into cars values(null,'$cartype','$carname','$farekm','$fareday','$ntsty','$nop','$image')";
	$result=mysql_query($sql,$link);
	if($result)
	{
		header("location:carEntry.php?ok=1");
	}
	else
	{
		echo mysql_error();
	}
}
?>

	