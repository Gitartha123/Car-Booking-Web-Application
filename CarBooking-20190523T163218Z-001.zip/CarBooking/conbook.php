<?php
	include "connect.php";
	if(isset($_POST["submit"]))
	{
		$bid=$_POST["bid"];
		if(isset($_POST["driver"]))
		{
			$driver=$_POST["driver"];	
		}
		else
		{
			$driver=0;	
		}
		$act=$_POST["act"];
		$remarks=$_POST["remarks"];
		$result=mysql_query("Update booking set status='$act',driver='$driver',remarks='$remarks' where bid='$bid'");
		if($result)
		{
			header("location:viewcarbooking.php");
		}
		else
		{
			echo mysql_error();	
		}
	}
?>