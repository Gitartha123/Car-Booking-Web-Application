<?php
	session_start();
	include "connect.php";
	if(isset($_POST["submit"]))
	{
		$td=mysql_real_escape_string($_POST["tdate"]);
		$tdate=date("Y-m-d",strtotime($td));
		$ctype=$_POST["ctype"];
		$model=$_POST["model"];
		$mode=$_POST["mode"];
		$contact=$_POST["contact"];
		$pplace=$_POST["pplace"];
		$ptime=$_POST["ptime"];
		$bdate=date("Y-m-d");
		$ctime=date("h:i:s");
		
		$ctime=str_replace(':','',$ctime);
		$bid=substr($ctype,0,3).substr($bdate,5,2).substr($bdate,8,2).$ctime;
		$cid=$_SESSION["username"];
		$sql="insert into booking values('$bid','$bdate','$tdate','$cid','$model','$mode','$contact','$pplace','$ptime',0,'Pending','NR')";
		$result=mysql_query($sql);
			
		if($result)
		{
			header("location:userhome.php?bid=".$bid);
		}
		else
		{
			echo mysql_error();	
		}
		
	}
?>