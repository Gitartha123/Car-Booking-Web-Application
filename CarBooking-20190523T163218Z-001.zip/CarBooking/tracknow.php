<?php
	session_start();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Rent a Car</title>
<link href="a1style.css" rel="stylesheet">
<style>
	.nounder
	{
		text-decoration:none;	
	}
	.nounder:hover
	{
		color:#0C6;	
	}
</style>
<script>
function myFunction() {
    var x = document.getElementById("vmenu");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
</script>
</head>

<body>
<div class="a1-container a1-red a1-small a1-padding-8">
	<div class="a1-row">
    	<div class="a1-half">
        	<div class="a1-bar">
        		<span class="a1-bar-item">Phone : +91-9954425896 | Email : customercare@easyway.com</span>
            </div>
        </div>
        <div class="a1-half">
        	<div class="a1-bar">
 				
            	<a href="contact.php" class="a1-bar-item a1-hide-small nounder a1-right">Contact Us</a>
                <a href="busforpicnic.php" class="a1-bar-item a1-hide-small nounder a1-right">Bus for Picnic</a>
                <a href="weddingcars.php" class="a1-bar-item a1-hide-small nounder a1-right">Wedding Cars</a>
                <a href="carrental.php" class="a1-bar-item a1-hide-small nounder a1-right">Car Rental</a>
            	<a href="index.php" class="a1-bar-item nounder a1-right">Home</a>

            </div>
        </div>
    </div>
	
</div>
<img src="images/car-rental.png" style="width:100%;"/>
<div class="a1-container a1-small" style="margin-top:20px; margin-bottom:20px;">
	<div class="a1-card" style="width:600px; margin:0 auto;">
	  <div class="a1-container a1-blue-gray">
      	<h6>CAR BOOKING TRACKING DETAILS</h6>
      </div>
      <div class="a1-container a1-small a1-padding-12">
    	<?php
					include "connect.php";
	                $bid=$_POST["bid"];
					$result=mysql_query("Select * from booking where bid='$bid'");
					$n=mysql_num_rows($result);
					if($n==0)
					{
						header("location:userhome.php?book=0");
						return;	
					}
					$row=mysql_fetch_array($result);
					$status=$row["status"];
					if($status=="Pending")
					{
						header("location:userhome.php?pen=1");
						return;	
					}
					else if($status=="Reject")
					{
						header("location:userhome.php?rej=".$row["remarks"]);
						
						return;	
					}
					else if($status=="Cancelled")
					{
					     header("location:userhome.php?can=1");		
					}
		?>

		<table width="80%" border="0" align="center" cellpadding="0" cellspacing="5">
		  <tr>
		    <td height="32" colspan="2" align="center"><strong style="color: #F00">YOUR BOOKING IS CONFIRMED</strong></td>
	      </tr>
		  <tr>
		    <td width="50%">BOOKING ID:</td>
		    <td width="50%"><?php echo $row[0]; ?></td>
	      </tr>
		  <tr>
		    <td>BOOKING DATE:</td>
		    <td><?php echo $row[1]; ?></td>
	      </tr>
		  <tr>
		    <td>TRAVEL DATE:</td>
		    <td><?php echo $row[2]; ?></td>
	      </tr>
		  <tr>
		    <td>CAR MODEL:</td>
		    <td><?php echo $row[4]; ?></td>
	      </tr>
          <?php
		  	$did=$row["driver"];
			$result=mysql_query("Select * from drivers where id='$did'");
			$row=mysql_fetch_array($result);
		  ?>
		  <tr>
		    <td>DRIVER NAME:</td>
		    <td><?php echo $row[1]; ?></td>
	      </tr>
		  <tr>
		    <td>DRIVER PHONE:</td>
		    <td><?php echo $row[2]; ?></td>
	      </tr>
		  <tr>
		    <td valign="top">DRIVER PHOTO:</td>
		    <td valign="top"><img src="<?php echo $row[3]; ?>" width="100" height="100"></td>
	      </tr>
		  <tr>
		    <td height="37" colspan="2" align="center"><a href="userhome.php"><input class="a1-btn a1-indigo" type="button" name="button" id="button" value="Go Back"></a></td>
	      </tr>
	    </table>
      </div>
      
  </div>
</div>
<div class="a1-container a1-blue-gray a1-padding-16">
	<div style="float:left;">Copyright @ easyway cars</div>
    <div style="float:right;">
    	Designed By 
    </div>
</div>
</body>
</html>
