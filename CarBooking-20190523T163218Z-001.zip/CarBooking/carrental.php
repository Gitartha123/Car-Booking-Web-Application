<?php
	session_start();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Rent a Car</title>
<link href="a1style.css" rel="stylesheet">
<style>
	.nounder
	{
		text-decoration:none;	
	}
	.nounder:hover
	{
		color:#0C6;	
	}
	a:link{ text-decoration:none; }
</style>
<script>
function myFunction() {
    var x = document.getElementById("vmenu");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}

</script>
</head>

<body>
<div class="a1-container a1-red a1-small a1-padding-8">
	<div class="a1-row">
    	<div class="a1-third">
        	<div class="a1-bar">
        		<span class="a1-bar-item">Phone : +91-9954425896 | Email : customercare@easyway.com</span>
            </div>
        </div>
        <div class="a1-rest">
        	<div class="a1-bar">
            	<a onclick="document.getElementById('id01').style.display='block'" class="a1-bar-item a1-hide-small nounder a1-right" style="cursor:pointer;">Track Booking</a>
            	<a href="contact.php" class="a1-bar-item a1-hide-small nounder a1-right">Contact Us</a>
                <a href="busforpicnic.php" class="a1-bar-item a1-hide-small nounder a1-right">Bus for Picnic</a>
                <a href="weddingcars.php" class="a1-bar-item a1-hide-small nounder a1-right">Wedding Cars</a>
                <a href="carrental.php" class="a1-bar-item a1-hide-small nounder a1-right">Car Rental</a>
                   
            	<a href="index.php" class="a1-bar-item nounder a1-right">Home</a>
            </div>
        </div>
    </div>
	
</div>
<img src="images/car-rental.png" style="width:100%;"/>
<div class="a1-container a1-small" style="margin-top:20px; margin-bottom:20px;">
	<div class="a1-card-4 a1-small" style="margin:10px auto; width:1200px;">
    	<div class="a1-container a1-blue a1-center">
        	<table width="100%" border="0" cellspacing="2" cellpadding="0">
        	  <tr>
        	    <td width="26%" align="left">Welcome 
					<?php 
						if(isset($_SESSION["status"]))
						{
							echo $_SESSION["username"].' | <a href="logout.php">Logout</a>'; 
						}
						else
						{
							echo 'GUEST';	
						}
					?></td>
        	    <td width="74%" align="center"><h6>CAR DETAILS</h6></td>
      	    </tr>
      	  </table>
        </div>
        <div class="a1-row-padding">
        	<div class="a1-quarter">
            	<div class="a1-container a1-light-gray a1-padding-8">
               	  <form id="form1" name="form1" method="post">
               	    <p>
               	      <select class="a1-select" name="cartype" id="cartype">
               	        <option>-----Select Car Type-----</option>
               	        <option>SUV</option>
               	        <option>Sedan</option>
               	        <option>Hatchback</option>
               	        <option>Van</option>
               	        <option>Others</option>
           	          </select>
               	    </p>
               	    <p align="right">
               	      <input class="a1-btn a1-green a1-round" type="submit" name="submit" id="submit" value="Search">
                      <a href="carrental.php"><input class="a1-btn a1-green a1-round" type="button" name="refresh" id="refresh" value="Refresh"></a>
                    </p>
              	  </form>
                </div>
            </div>
            <div class="a1-rest">
            	<div class="a1-container a1-light-gray a1-padding-8">
            	  <table class="a1-table-all" width="100%">
                	    <tr class="a1-blue-gray">
                	      <td>Car Type</td>
                	      <td>Model</td>
                	      <td>Rate/KM</td>
                	      <td>Rate/Day</td>
                	      <td>Night Stay</td>
                	      <td>Persons</td>
                	      <td>Photo</td>
                	      <td style="width:100px; text-align:center;">&nbsp;</td>
              	      </tr>
                      <?php
					  	include "connect.php";
						if(isset($_POST["submit"]))
						{
							$ctype=$_POST["cartype"];
							$result=mysql_query("Select * from cars where cartype='$ctype'");
						}
						else
						{
							$result=mysql_query("Select * from cars");	
						}
						
						while($row=mysql_fetch_array($result))
						{
							echo '<tr>';
							echo '<td>'.$row[1].'</td>';
							echo '<td>'.$row[2].'</td>';
							echo '<td>'.$row[3].'</td>';
							echo '<td>'.$row[4].'</td>';
							echo '<td>'.$row[5].'</td>';
							echo '<td>'.$row[6].'</td>';
							echo '<td><img src="'.$row[7].'" width="70" height="50"></td>';
							echo '<td><a class="a1-btn a1-green a1-round" href="bookcar.php?cid='.$row[0].'&ctype='.$row[1].'&model='.$row[2].'">Book Now</a></td>';
							echo '</tr>';
						}
					  ?>
              	    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="a1-container a1-blue-gray a1-padding-16">
	<div style="float:left;">Copyright @ easyway cars</div>
    <div style="float:right;">
    	Designed By Gitartha Puzari & Pranjit Dutta
    </div>
</div>

<div class="a1-container">
  <div id="id01" class="a1-modal">
    <div class="a1-modal-content a1-card-4 a1-animate-zoom a1-pale-red" style="max-width:400px">

      <div class="a1-center"><br>
        <span onclick="document.getElementById('id01').style.display='none'" class="a1-button a1-pale-red a1-xlarge a1-hover-red a1-display-topright" title="Close Modal">&times;</span>
        <img src="images/magnifier.png" style="width:30%" class="a1-margin-top"><br>
		TRACK YOUR BOOKING
      </div>

      <form name="form3" id="form3" class="a1-container" method="post" action="tracknow.php">
        <div class="a1-section" style="padding-bottom:10px;">
          <label><b>Enter Booking ID</b></label>
          <input class="a1-input a1-border a1-round a1-margin-bottom" type="text" name="bid" required>
          <button class="a1-button a1-block a1-red a1-section a1-padding" type="submit" name="submit">Submit</button>
          
        </div>
      </form>
	
    </div>
  </div>
</div>

</body>
</html>
<?php
	if(isset($_GET["ok"]))
	{
		echo '<script> alert("Registration Completed"); </script>';	
	}
?>