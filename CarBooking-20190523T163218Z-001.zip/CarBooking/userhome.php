<?php
	session_start();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Rent a Car</title>
<link href="a1style.css" rel="stylesheet">
<style>
	.mySlides {display:none;}
	label.error 
	{
    color: red;
    }
</style>
<style>
	.nounder
	{
		text-decoration:none;	
	}
	.nounder:hover
	{
		color:#0C6;	
	}
	a:link{ text-decoration:none; }
</style>
<script src="jQueryAssets/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="jQueryAssets/jquery-ui-1.9.2.datepicker.custom.min.js" type="text/javascript"></script>
<script src="js/jquery.validate.js" type="text/javascript"></script>
<script>
function myFunction() {
    var x = document.getElementById("vmenu");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
$(document).ready(function() {
	$.validator.addMethod("valueNotEquals", function(value, element, arg){
		  return arg != value;
		 }, "Value must not equal arg.");
		 
		 jQuery.validator.addMethod("lettersonly", function(value, element) {
		  return this.optional(element) || /^[a-z\s]+$/i.test(value);
		}, "Please type letters only"); 
		
    $("#form4").validate({
					rules: {
						
						username: { required: true },
						password: { required: true , minlength:5},
						password2:{required:true, equalTo:"#password"}
						
					},
					messages: {
						username: { required:"Enter username" },
						password: { required:"Enter password",minlength:"Enter atleast 5 characters" },
						password2:{required:"Enter the same password",equalTo:"password doesnot match"}
	               
					}
				});
});
</script>
</head>

<body>
<div class="a1-container a1-red a1-small a1-padding-8">
	<div class="a1-row">
    	<div class="a1-third">
        	<div class="a1-bar">
        		<span class="a1-bar-item">Phone :+91-9954425896 | Email : customercare@easyway.com</span>
            </div>
        </div>
        <div class="a1-rest">
        	<div class="a1-bar">
            	<a onclick="document.getElementById('id01').style.display='block'" class="a1-bar-item a1-hide-small nounder a1-right" style="cursor:pointer;">Track Booking</a>
            	<a href="contact.php" class="a1-bar-item a1-hide-small nounder a1-right">Contact Us</a>
                <a href="busforpicnic.php" class="a1-bar-item a1-hide-small nounder a1-right">Bus for Picnic</a>
                <a href="weddingcars.php" class="a1-bar-item a1-hide-small nounder a1-right">Wedding Cars</a>
                <a href="carrental.php" class="a1-bar-item a1-hide-small nounder a1-right">Car Rental</a>
                <a href="mybooking.php" class="a1-bar-item a1-hide-small nounder a1-right">My Booking</a>
            	<a href="index.php" class="a1-bar-item nounder a1-right">Home</a>
            </div>
        </div>
    </div>
	
</div>
<img src="images/car-rental.png" style="width:100%;"/>
<div class="a1-container a1-small" style="margin-top:20px; margin-bottom:20px;">
	<div class="a1-row-padding">
    	 <div class="a1-third">
        	<div class="a1-card-4 a1-light-gray" style="height:200px; background-image:url(pics/audi-a6.jpg); background-size:cover;">
            	<div class="a1-container a1-blue-gray a1-right">
                    	<h6><a href="weddingcars.php">Wedding Cars</a></h6>
                </div>
                <div>
                		<!--<img src="images/sddefault.jpg" height="150" style="width:100%;"/>-->
                </div> 
          </div>	
        </div>
        <div class="a1-third">
        	<div class="a1-card-4 a1-light-gray" style="height:200px; background-image:url(pics/20150910112356_DSC_2813.JPG); background-size:cover;">
            	<div class="a1-container a1-blue-gray a1-right">
                    	<h6><a href="carrental.php">Car Rental Package</a></h6>
                </div>
                <div>
                		<!--<img src="images/sddefault.jpg" height="150" style="width:100%;"/>-->
                </div> 
          </div>	
        </div>
        <div class="a1-third">
        	<div class="a1-card-4 a1-light-gray" style="height:200px;">
            	<div class="a1-container a1-blue-gray">
            	  <h6>Welcome <?php echo $_SESSION["username"]; ?> | <a href="logout.php">Logout</a> | <a onclick="document.getElementById('id02').style.display='block'" class="a1-bar-item a1-hide-small nounder a1-right" style="cursor:pointer;">Change Password</a></h6>
                </div>
                <div class="a1-container a1-padding-12">
                	
               	  <form name="form2" id="form2" method="post" action="tracknow.php">
                   	<table width="100%" border="0" cellspacing="2" cellpadding="2">
                    	  <tr>
                    	    <td colspan="2" align="center">TRACK BOOKING</td>
                   	    </tr>
                    	  <tr>
                    	    <td width="35%">Enter Booking ID:</td>
                    	    <td width="65%"><input name="bid" type="text" required class="a1-input" id="bid"></td>
                  	    </tr>
                    	  <tr>
                    	    <td height="46"></td>
                    	    <td><input class="a1-btn-block a1-red" type="submit" name="submit" id="submit" value="Track Now"></td>
               	      </tr>
               	    </table>
                	</form>
                </div>
            </div>	
        </div>
    </div>
</div>
<div class="a1-container a1-blue-gray a1-padding-16">
	<div style="float:left;">Copyright @ easyway cars</div>
    <div style="float:right;">
    	Designed By 
        Gitartha Puzari & Pranjit Dutta
    </div>
</div>

<div class="a1-container">
  <div id="id01" class="a1-modal">
    <div class="a1-modal-content a1-card-4 a1-animate-zoom a1-pale-red" style="max-width:400px">

      <div class="a1-center"><br>
        <span onclick="document.getElementById('id01').style.display='none'" class="a1-button a1-pale-red a1-xlarge a1-hover-red a1-display-topright" title="Close Modal">&times;</span>
        <img src="images/magnifier.png" style="width:30%" class="a1-margin-top"><br>
		TRACK YOUR BOOKING
      </div>

      <form name="form3" id="form3" class="a1-container" method="post" action="tracknow.php">
        <div class="a1-section" style="padding-bottom:10px;">
          <label><b>Enter Booking ID</b></label>
          <input class="a1-input a1-border a1-round a1-margin-bottom" type="text" name="bid" required>
          <button class="a1-button a1-block a1-red a1-section a1-padding" type="submit" name="submit">Submit</button>
          
        </div>
      </form>
	
    </div>
  </div>
</div>
  <div class="a1-container">
  <div id="id02" class="a1-modal">
    <div class="a1-modal-content a1-card-4 a1-animate-zoom a1-pale-red" style="max-width:400px">

      <div class="a1-center"><br>
        <span onclick="document.getElementById('id02').style.display='none'" class="a1-button a1-pale-red a1-xlarge a1-hover-red a1-display-topright" title="Close Modal">&times;</span>
        <img src="images/100px-1162_key.png" style="width:30%" class="a1-margin-top"><br>
		CHANGE YOUR PASSWORD
      </div>

      <form name="form4" id="form4" class="a1-container" method="post" action="prochpass.php">
        <div class="a1-section" style="padding-bottom:10px;">
                 <table width="100%" border="0" cellspacing="2" cellpadding="1">
            	<?php
				
					include "connect.php";
					$id=$_SESSION["username"];
					$result=mysql_query("Select * from users where username='$id'");
					$row=mysql_fetch_array($result);
				?>
              <tr>
                  <td width="38%">USER ID</td>
                  <td width="62%"><input class="w3-input w3-border w3-round" type="text" name="username" id="username" value="<?php echo $row["username"]; ?>"placeholder="Enter username"></td>
              </tr>
              <tr>
                <td valign="top">New Password:</td>
                <td><input class="w3-input w3-border w3-round" type="password" name="password" id="password"placeholder="Enter password"></td>
              </tr>
              <tr>
                <td valign="top">Confirm Password:</td>
                <td><input class="w3-input w3-border w3-round" type="password" name="password2" id="password2"placeholder="Retype your password"></td>
              </tr>
              <tr>
                <td height="48">&nbsp;</td>
                <td><input class="w3-btn  w3-red" type="submit" name="submit" id="submit" value="Update"></td>
              </tr>
            </table>
          
        </div>
      </form>
	
    </div>
  </div>
</div>

</body>
</html>
<?php
	if(isset($_GET["bid"]))
	{
		$bid=$_GET["bid"];
		echo '<script> alert("Thank you for booking a car.\n\nYour Booking ID is '.$bid.'.\n\nUse this id to track your booking..."); </script>';	
	}

if(isset($_GET["p"]))
	{
		echo '<script> alert("Your password has been changed"); </script>';	
	}
if(isset($_GET["pen"]))
	{
		echo '<script> alert("Booking is Pending. Track again later"); </script>';	
	}
	if(isset($_GET["book"]))
	{
		echo '<script> alert("Incorrect Booking ID"); </script>';	
	}
	if(isset($_GET["rej"]))
	{
		echo '<script> alert("Sorry your Booking is Rejected. '.$_GET["rej"].'"); </script>';	
	}
	if(isset($_GET["can"]))
	{
		echo '<script> alert("Booking is cancelled"); </script>';	
	}
?>