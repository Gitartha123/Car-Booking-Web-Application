<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link href="a1style.css" type="text/css" rel="stylesheet"/>
<script src="jQueryAssets/jquery-1.8.3.min.js" type="text/javascript"></script>
<style>
	.nounder
	{
		text-decoration:none;	
	}
	.nounder:hover
	{
		color:#0C6;	
	}
</style>
<script>
function myFunction() {
    var x = document.getElementById("vmenu");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}

$(document).ready(function() {
    $("#act").change(function() {
        var x=$("#act").val();
		if(x=="Reject")
		{
			$("#driver").attr("disabled",true);	
		}
		else
		{
			$("#driver").attr("disabled",false);	
		}
    });
});
</script>
</head>

<body>
<div class="a1-container a1-red a1-small a1-padding-8">
	<div class="a1-row">
    	<div class="a1-half">
        	<div class="a1-bar">
        		<span class="a1-bar-item">Phone : +91-9954425896 | Email : customercare@easyway.com</span>
                <P align="center">&nbsp;</P></div>
        </div>
        <div class="a1-half">
        	<div class="a1-bar">
            	<?php include "amenu.php"; ?>
            </div>
        </div>
    </div>
	
</div>
<img src="images/car-rental.png" style="width:100%;"/>
<div class="a1-container a1-small" style="margin-top:20px; margin-bottom:20px;">
	<div class="a1-card-4 a1-light-gray" style="width:500px; margin:30px auto;">
   	  <div class="a1-container a1-blue">
        	<h6>CONFIRM / REJECT BOOKING</h6>
        </div>
        <div class="a1-container a1-padding-12">
          <form action="conbook.php" method="post" enctype="multipart/form-data"  name="form1" id="form1">
            <table width="100%" border="0" cellspacing="2" cellpadding="1">
              <tr>
                <td width="38%">BOOKING ID:</td>
                <td width="62%"><input name="bid"type="text" class="a1-input a1-border a1-round" id="bid" readonly value="<?php echo $_GET["bid"]; ?>"></td>
              </tr>
              <tr>
                <td height="32">ACTION:</td>
                <td><select class="a1-select a1-border" name="act" id="act">
                  <option selected="selected">Select Action</option>
                  <option>Confirm</option>
                  <option>Reject</option>
                </select></td>
              </tr>
              <tr>
                <td>ASSIGN DRIVER:</td>
                <td><select class="a1-select a1-border a1-round" name="driver" id="driver">
                  <option>Select Driver</option>
                  <?php
				  	include "connect.php";
					$result=mysql_query("Select * from drivers");
					while($row=mysql_fetch_array($result))
					{
						echo '<option value="'.$row[0].'">'.$row[1].'</option>';	
					}
				  ?>
                </select></td>
              </tr>
              <tr>
                <td>REMARKS:</td>
                <td><textarea name="remarks" required="required" class="a1-input a1-border a1-round" id="remarks"></textarea></td>
              </tr>
              <tr>
                <td height="48">&nbsp;</td>
                <td><input class="a1-btn-block a1-red" type="submit" name="submit" id="submit" value="Submit"></td>
              </tr>
            </table>
          </form>
        </div>
    </div>
</div>
<div class="a1-container a1-blue-gray a1-padding-16">
	<div style="float:left;">Copyright @ easyway cars</div>
    <div style="float:right;">
    	Designed By 
    </div>
</div>

</body>
</html>
<?php
if(isset($_GET["ok"]))
{
	echo '<script>alert("submitted succesfully");</script>';
}
?>