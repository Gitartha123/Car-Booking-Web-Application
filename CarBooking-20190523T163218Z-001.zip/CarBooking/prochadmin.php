<?php
    
	include "connect.php";
	$id=$_POST["username"];
	$pass=$_POST["password"];
	$result=mysql_query("Update login set password='$pass' where username='$id'");
	if($result)
	{
		header("location:adminhome.php?p=1");	
	}
	else
	{
		echo mysql_error();	
	}
?>