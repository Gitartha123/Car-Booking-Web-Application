<?php
	include "connect.php";
	$id=$_GET["bid"];
	mysql_query("update picnicbooking set status='rejected' where bid='$id'");
	header("location:viewpicnicbooking.php");
?>