<?php
	include "connect.php";
	$id=$_GET["cid"];
	mysql_query("delete from drivers where id='$id'");
	header("location:viewdriver.php");
?>