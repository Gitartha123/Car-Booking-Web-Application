<?php
	include "connect.php";
	$id=$_GET["bid"];
	mysql_query("update wcarbooking set status='Rejected' where bid='$id'");
	header("location:viewwcarbooking.php");
?>