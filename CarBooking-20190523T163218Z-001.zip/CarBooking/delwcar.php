<?php
	include "connect.php";
	$id=$_GET["cid"];
	mysql_query("delete from wedding where id='$id'");
	header("location:wcarview.php");
?>