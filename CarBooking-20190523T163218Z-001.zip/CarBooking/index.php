<?php
	session_start();
	if(isset($_SESSION["admin"]))
	{
		header("location:adminhome.php");
	}
	if(isset($_SESSION["status"]))
	{
		header("location:userhome.php");
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Rent a Car</title>
<link href="a1style.css" rel="stylesheet">
<style>
	.nounder
	{
		text-decoration:none;	
	}
	.nounder:hover
	{
		color:#0C6;	
	}
	a:link{ text-decoration:none; }
</style>
<script>
function myFunction() {
    var x = document.getElementById("vmenu");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}

</script>
</head>

<body>
<div class="a1-container a1-red a1-small a1-padding-8">
	<div class="a1-row">
    	<div class="a1-third">
        	<div class="a1-bar">
        		<span class="a1-bar-item">Shivam Travels|Phone :9954425896 | Email : customercare@easyway.com</span>
            </div>
        </div>
        <div class="a1-rest">
        	<div class="a1-bar">
            	<a onclick="document.getElementById('id01').style.display='block'" class="a1-bar-item a1-hide-small nounder a1-right" style="cursor:pointer;">Track Booking</a>
            	<a href="contact.php" class="a1-bar-item a1-hide-small nounder a1-right">Contact Us</a>
                <a href="busforpicnic.php" class="a1-bar-item a1-hide-small nounder a1-right">Bus for Picnic</a>
                <a href="weddingcars.php" class="a1-bar-item a1-hide-small nounder a1-right">Wedding Cars</a>
                <a href="carrental.php" class="a1-bar-item a1-hide-small nounder a1-right">Car Rental</a>
            	<a href="index.php" class="a1-bar-item nounder a1-right">Home</a>
            </div>
        </div>
    </div>
	
</div>
<img src="images/car-rental.png" style="width:100%;"/>
<div class="a1-container a1-small" style="margin-top:20px; margin-bottom:20px;">
	<div class="a1-row-padding">
    	 <div class="a1-third">
        	<div class="a1-card-4 a1-light-gray" style="height:200px; background-image:url(pics/audi-a6.jpg); background-size:cover;">
            	<div class="a1-container a1-blue-gray a1-right">
                    	<h6><a href="weddingcars.php">Wedding Cars</a></h6>
                </div>
                <div>
                		<!--<img src="images/sddefault.jpg" height="150" style="width:100%;"/>-->
                </div> 
          </div>	
        </div>
        <div class="a1-third">
        	<div class="a1-card-4 a1-light-gray" style="height:200px; background-image:url(pics/20150910112356_DSC_2813.JPG); background-size:cover;">
            	<div class="a1-container a1-blue-gray a1-right">
                    	<h6><a href="carrental.php">Car Rental Package</a></h6>
                </div>
                <div>
                		<!--<img src="images/sddefault.jpg" height="150" style="width:100%;"/>-->
                </div> 
          </div>	
        </div>
        <div class="a1-third">
        	<div class="a1-card-4 a1-light-gray" style="height:200px;">
            	<div class="a1-container a1-blue-gray">
            	  <h6>Existing User? Sign In | New User? <a href="registration.php">Click to Sign Up</a></h6>
                </div>
                <div class="a1-container a1-padding-12">
                	
               	  <form name="form2" id="form2" method="post" action="prologin.php">
                   	<table width="100%" border="0" cellspacing="2" cellpadding="2">
                    	  <tr>
                    	    <td width="35%">User Name:</td>
                    	    <td width="65%"><input name="username" type="text" required class="a1-input" id="username"></td>
                  	    </tr>
                    	  <tr>
                    	    <td>Password:</td>
                    	    <td><input name="password" type="password" required class="a1-input" id="password"></td>
                  	    </tr>
                    	  <tr>
                    	    <td height="46">&nbsp;</td>
                    	    <td><input class="a1-btn-block a1-red" type="submit" name="submit" id="submit" value="Login Now"></td>
               	      </tr>
               	    </table>
                	</form>
                </div>
            </div>	
        </div>
    </div>
</div>
<div class="a1-container a1-blue-gray a1-padding-16">
	<div style="float:left;">Copyright @ easyway cars</div>
    <div style="float:right;">
    	Designed By Gitartha Puzari & Pranjit Dutta
    </div>
</div>

<div class="a1-container">
  <div id="id01" class="a1-modal">
    <div class="a1-modal-content a1-card-4 a1-animate-zoom a1-pale-red" style="max-width:400px">

      <div class="a1-center"><br>
        <span onclick="document.getElementById('id01').style.display='none'" class="a1-button a1-pale-red a1-xlarge a1-hover-red a1-display-topright" title="Close Modal">&times;</span>
        <img src="images/magnifier.png" style="width:30%" class="a1-margin-top"><br>
		TRACK YOUR BOOKING
      </div>

      <form name="form3" id="form3" class="a1-container" method="post" action="track.php">
        <div class="a1-section" style="padding-bottom:10px;">
          <label><b>Enter Booking ID</b></label>
          <input class="a1-input a1-border a1-round a1-margin-bottom" type="text" name="bid" required>
          <button class="a1-button a1-block a1-red a1-section a1-padding" type="submit" name="submit">Submit</button>
          
        </div>
      </form>
	
    </div>
  </div>
</div>

</body>
</html>
<?php
	if(isset($_GET["ok"]))
	{
		echo '<script> alert("Registration Completed"); </script>';	
	}
	if(isset($_GET["log"]))
	{
		echo '<script> alert("You need to login"); </script>';	
	}
	if(isset($_GET["book"]))
	{
		echo '<script> alert("Incorrect Booking ID"); </script>';	
	}
	if(isset($_GET["pen"]))
	{
		echo '<script> alert("Booking is Pending. Track again later"); </script>';	
	}
	if(isset($_GET["rej"]))
	{
		echo '<script> alert("Sorry your Booking is Rejected. '.$_GET["rej"].'"); </script>';	
	}
	if(isset($_GET["pwd"]))
	{
		echo '<script> alert("wrong password"); </script>';	
	}
	if(isset($_GET["can"]))
	{
		echo '<script> alert("Booking is cancelled"); </script>';	
	}
	
?>