<?php
	include "connect.php";
	$id=$_GET["bid"];
	mysql_query("update picnicbooking set status='Confirmed' where bid='$id'");
	header("location:viewpicnicbooking.php");
?>