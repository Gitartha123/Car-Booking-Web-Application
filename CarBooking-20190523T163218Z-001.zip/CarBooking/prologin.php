<?php
	session_start();
	include "connect.php";
	if(isset($_POST["submit"]))
	{
		$usernm=$_POST["username"];
		$pass=$_POST["password"];
		if($usernm=="admin")
		{
			$sql="select * from login where username='$usernm'";
			$result=mysql_query($sql);
			$row=mysql_fetch_assoc($result);
			if($pass==$row["password"])
			{
				$_SESSION["admin"]=true;
				header("location:adminhome.php");	
			}
			else
			{
				header("location:index.php?pwd=0");	
			}
		}
		else
		{
			$sql="select * from users where username='$usernm'";
			$result=mysql_query($sql);
			$row=mysql_fetch_assoc($result);
			if($pass==$row["password"])
			{
				$_SESSION["username"]=$usernm;
				$_SESSION["status"]=true;
				header("location:userhome.php");	
			}
			else
			{
				header("location:index.php?pwd=0");	
			}
		}
		
    }

?>