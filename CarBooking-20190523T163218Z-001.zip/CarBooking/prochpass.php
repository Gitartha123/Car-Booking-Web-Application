<?php
    
	include "connect.php";
	$id=$_POST["username"];
	$pass=$_POST["password"];
	$result=mysql_query("Update users set password='$pass' where username='$id'");
	if($result)
	{
		header("location:userhome.php?p=1");	
	}
	else
	{
		echo mysql_error();	
	}
?>