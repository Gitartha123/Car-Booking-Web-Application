<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Rent a Car</title>
<link href="a1style.css" rel="stylesheet">
<style>
	.nounder
	{
		text-decoration:none;	
	}
	.nounder:hover
	{
		color:#0C6;	
	}
</style>
<script>
function myFunction() {
    var x = document.getElementById("vmenu");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}

</script>
</head>

<body>
<div class="a1-container a1-red a1-small a1-padding-8">
	<div class="a1-row">
    	<div class="a1-half">
        	<div class="a1-bar">
        		<span class="a1-bar-item">Phone : +91-9954425896 | Email : customercare@easyway.com</span>
            </div>
        </div>
        <div class="a1-half">
        	<div class="a1-bar">
            	<?php include "amenu.php"; ?>
            </div>
        </div>
    </div>
	
</div>
<img src="images/car-rental.png" style="width:100%;"/>
<div class="a1-container a1-small" style="margin-top:20px; margin-bottom:20px;">
	<div class="a1-card a1-gray" style="width:1000px; margin:0 auto;">
	  <div class="a1-container a1-blue-gray">
      	<h6>ADD RECORDS | <a onclick="document.getElementById('id03').style.display='block'" class="a1-bar-item a1-hide-small nounder a1-right" style="cursor:pointer;">Change Password</a></h6>
      </div>
      <div class="a1-row-padding">
      	<div class="a1-quarter">
        	<div class="a1-display-container a1-center" style="height:120px;">
                	<div class="a1-display-middle"> <a href="carentry.php"><img src="images/carEntry.png" style="width:100%"></a><br>
						Car Entry
                    </div>
            </div>
        </div>
        <div class="a1-quarter">
        	<div class="a1-display-container a1-center" style="height:120px;">
           	  <div class="a1-display-middle">
                    	<a href="driverentry.php"><img src="images/driver.png" style="width:100%"></a><br>
				  Driver Entry </div>
            </div>
        </div>
        <div class="a1-quarter">
        	<div class="a1-display-container a1-center" style="height:120px;">
           	  <div class="a1-display-middle">
                    	<a href="picnicentry.php"><img src="images/picnic.png" style="width:100%"></a><br>
				  Picnic Package </div>
            </div>
        </div>
        <div class="a1-quarter">
        	<div class="a1-display-container a1-center" style="height:120px;">
           	  <div class="a1-display-middle">
               	<a href="wcarentry.php"><img src="images/weddingCar.png" style="width:100%"></a><br>
				  Wedding Cars </div>
            </div>
        </div>
      </div>
      <div class="a1-container a1-blue-gray">
      	<h6>DISPLAY RECORDS</h6>
      </div>
      <div class="a1-row-padding">
      	<div class="a1-quarter">
        	<div class="a1-display-container a1-center" style="height:120px;">
                	<div class="a1-display-middle">
                    	<a href="viewcar.php"><img src="images/carEntry.png" style="width:100%"></a><br>
						View/Edit Cars
                    </div>
            </div>
        </div>
        <div class="a1-quarter">
        	<div class="a1-display-container a1-center" style="height:120px;">
                	<div class="a1-display-middle">
                    	<a href="viewdriver.php"><img src="images/driver.png" style="width:100%"></a><br>
						View/Edit Drivers
                    </div>
            </div>
        </div>
        <div class="a1-quarter">
        	<div class="a1-display-container a1-center" style="height:120px;">
                	<div class="a1-display-middle">
                    	<a href="viewpicnic.php"><img src="images/picnic.png" style="width:100%"></a><br>
						View/Edit Picnic Package
                    </div>
            </div>
        </div>
        <div class="a1-quarter">
        	<div class="a1-display-container a1-center" style="height:120px;">
                	<div class="a1-display-middle">
                    	<a href="wcarview.php"><img src="images/weddingCar.png" style="width:100%"></a><br>
						View/Edit Wedding Cars
                    </div>
            </div>
        </div>
      </div>
	</div>
</div>
<div class="a1-container a1-blue-gray a1-padding-16">
	<div style="float:left;">Copyright @ easyway cars</div>
    <div style="float:right;">
    	Designed By Gitartha Puzari & Pranjit Dutta
    </div>
</div>
 <div class="a1-container">
  <div id="id03" class="a1-modal">
    <div class="a1-modal-content a1-card-4 a1-animate-zoom a1-pale-red" style="max-width:400px">

      <div class="a1-center"><br>
        <span onclick="document.getElementById('id03').style.display='none'" class="a1-button a1-pale-red a1-xlarge a1-hover-red a1-display-topright" title="Close Modal">&times;</span>
        <img src="images/100px-1162_key.png" style="width:30%" class="a1-margin-top"><br>
		CHANGE YOUR PASSWORD
      </div>

      <form name="form3" id="form3" class="a1-container" method="post" action="prochadmin.php">
        <div class="a1-section" style="padding-bottom:10px;">
                 <table width="100%" border="0" cellspacing="2" cellpadding="1">
            	<?php
				    session_start();
					include "connect.php";

					$result=mysql_query("Select * from login where username='admin'");
					$row=mysql_fetch_array($result);
				?>
             
              <tr>
                <td valign="top">New Password:</td>
                <td><input class="w3-input w3-border w3-round" type="password" name="password" id="password"></td>
              </tr>
              <tr>
                <td valign="top">Confirm Password:</td>
                <td><input class="w3-input w3-border w3-round" type="password" name="password2" id="password2"></td>
              </tr>
              <tr>
                <td height="48">&nbsp;</td>
                <td><input class="w3-btn  w3-red" type="submit" name="submit" id="submit" value="Update"></td>
              </tr>
            </table>
          
        </div>
      </form>
	
    </div>
  </div>
</div>
</body>
</html>
<?php
if(isset($_GET["p"]))
	{
		echo '<script> alert("Your password has been changed"); </script>';	
	}
	?>