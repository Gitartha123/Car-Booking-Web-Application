<?php
include "connect.php";
if(isset($_POST["submit"]))
{
	
	$id=$_POST["cid"];
	$cartype=$_POST["selectype"];
	$carname=$_POST["carname"];
	$farekm=$_POST["farekm"];
	$fareday=$_POST["fareday"];
	$ntsty=$_POST["ntsty"];
	$nop=$_POST["nop"];
	$image=$_POST["photo"];
	
	if(!empty($_FILES['file1']['name']))
	{
		$target_dir = "cars/";
		$file = $target_dir . basename($_FILES["file1"]["name"]);
		
		$fileData = pathinfo(basename($_FILES["file1"]["name"]));
		
				
		$fileName = uniqid() . '.' . $fileData['extension'];
		$target_path = "cars/" . $fileName;
			
		while(file_exists($target_path))
		{
			$fileName = uniqid() . '.' . $fileData['extension'];
			$target_path = "cars/" . $fileName;
		}
		move_uploaded_file($_FILES["file1"]["tmp_name"], $target_path);
		
		$image="cars/" . $fileName;
	}
	
	
	//echo $image;
	$sql="update cars set cartype='$cartype',carmodel='$carname',ratekm='$farekm',rateday='$fareday',nop='$nop',nightstay='$ntsty',photo='$image' where id='$id'";
	$result=mysql_query($sql,$link);
	if($result)
	{
		header("location:viewcar.php?cid=1".$id);
		return;
	}
	else
	{
		echo mysql_error();
	}
	
}
?>

	